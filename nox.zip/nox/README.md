# nox

A launcher that **is** a terminal. Pure black, one screen, no icons, no grid, no pages.
Open the phone and you see a big clock, a tiny fastfetch, a row of pinned apps, and a blinking cursor.
Type part of an app name and press enter. That is the whole interface.

```
 ▄▄▄▄▄▄  ▄▄▄▄▄▄      ▄▄  ▄▄  ▄▄▄▄▄▄
 ██  ██  ██▄▄██  ▀▀  ██▄▄██  ██▄▄▄▄
 ██▄▄██  ██▄▄██  ▀▀      ██  ▄▄▄▄██

 Monday · 09 November 2026

 user@nox
 ────────
 os       Android 15 · One UI 7.0
 battery  ━━━━━━━━────  72% · charging
 memory   ━━━━━━──────  3.1G / 7.4G

 [phone]  [messages]  [camera]  [browser]  [settings]

 ❯ chr▌
 ▸ chrome            app
   calc              cmd
```

* No INTERNET permission. It physically cannot phone home.
* No dependencies at all (no AndroidX, no Compose). Plain Android framework + Kotlin, ~150 KB.
* Works with a locked bootloader. It is a normal app.

## Build it (GitHub does it for you)

1. Create a new **private** repo on GitHub and push this folder:
   ```
   git init && git add . && git commit -m "nox"
   git branch -M main
   git remote add origin https://github.com/<you>/nox.git
   git push -u origin main
   ```
2. Open the repo's **Actions** tab. The `build apk` workflow runs by itself (about 4-6 minutes the first time).
3. Open the finished run, scroll to **Artifacts**, download `nox-apk`, unzip, you have `nox.apk`.

Easier on a phone: push a tag and the APK is attached to a **Release** page you can open in the phone browser:
```
git tag v1.0 && git push --tags
```

The APK is signed with the key in `app/nox.jks`, the same one on every build. That is what lets a new build
install straight over the old one. Keep the repo private, or replace that key with your own.

## Install and make it your home

1. Install the APK (allow "install unknown apps" for your browser/file manager when asked).
2. Open **nox** once, then type `settings home` (or: Settings > Apps > Choose default apps > Home app) and pick **nox**.
3. Samsung: to hide the navigation bar completely go to Settings > Display > Navigation bar > **Swipe gestures** >
   More options > turn off **Gesture hint**. Then nothing is on screen but nox.
4. Screen lock: Settings > Lock screen > Screen lock type > **None** gives you "open the phone and it is just the terminal".
   (Anyone who picks up the phone then has full access, so decide for yourself.)

## Using it

Just type. Whatever you type is matched against your apps (prefix, word, initials `gm` = Google Maps, fuzzy `cmra`).
`enter` runs the top suggestion, or tap any suggestion. Frequently used apps rank higher over time.

| you type | what happens |
|---|---|
| `chr` + enter | launches Chrome |
| `2+2*3`, `sqrt(2)`, `17%5` | calculates right there |
| `github.com` | opens the link |
| `? best pizza` | web search (engine: `set engine ddg\|google\|brave\|bing\|startpage`) |
| `call mom` | finds the contact, opens the dialer (asks for contacts permission once) |
| `flash` / `vol 40` / `pp` | flashlight / media volume / play-pause |
| `alarm 6:45 gym` / `timer 10m` | sets it in your clock app |
| `todo buy milk`, `todo rm 1` | tiny todo list (`set todos 3` shows it on home) |
| `pin spotify` / `unpin spotify` | edit the dock row |
| `hide tiktok` | gone from lists and suggestions (typing its exact name still launches it) |
| `alias night="vol 0; flash off"` | your own macros. `a; b` chains commands |
| `settings wifi`, `settings battery`, `settings home` ... | straight to a settings page |
| `tui`, `music` | terminal apps in Termux (see below) |
| `help`, `help set` | everything else |

Gestures: **swipe down** = notifications, **swipe up** = keyboard, **Home** = reset to a clean screen,
**Back** = clear the prompt. A hardware keyboard gets TAB (complete) and up/down (history).

## Make it yours

```
theme            list themes: void matrix amber ice rose mono nord dracula gruvbox
set              every setting, with its current value
set size 14      font size          set clock small|big|off
set kbd auto     keyboard on every home press
set autolaunch on   launch as soon as exactly one app matches
set fields os,uptime,battery,storage   choose the panel lines
set header off   hide the whole panel (even more darkness)   set dock off   hide the pinned row
set wallpaper on; set dim 80   show your wallpaper darkened
set cursor bar   set prompt λ   set user you   set host phone
```

## Terminal apps through Termux (`tui`)

nox launches full-screen terminal programs inside [Termux](https://github.com/termux/termux-app/releases) and brings
you back when you quit. The first one is a music player: **mpd + ncmpcpp + cava in tmux**, themed from nox.

Setup, from inside nox:

1. Install **Termux from F-Droid or GitHub** (not the Play Store). Open it once.
2. `tui check` copies one line to your clipboard. Paste it in Termux, press enter, close Termux completely.
3. `tui setup` installs and configures everything (the script is `app/src/main/assets/termux/nox-music.sh`).
4. Put music in `/sdcard/Music`, then type **`music`**.

The same script works on its own inside Termux, with no nox involved:

```
bash nox-music.sh wipe              remove everything, old setups included
bash nox-music.sh install [theme]   void matrix amber ice rose mono nord dracula gruvbox
bash nox-music.sh theme nord        recolor only
bash nox-music.sh doctor            says exactly what is wrong
```

Keys in ncmpcpp: `2` file browser, `space` adds, `1` playlist, `enter` plays, `p` pause, `>` `<` next/prev,
`+` `-` volume, `q` quit. Touch and mouse work too.

`theme` changes in nox re-color Termux automatically. Add more apps with `tui add files nnn`; each name then works
like an app (suggestions, `open`, `pin`). A tui named like a built-in command wins, which is how `music` stops
opening the GUI player.

Limits: Android may kill background processes (the "phantom process killer"), which can stop mpd mid-song.
This plays a **local music library**, not Spotify or YouTube Music.

## Optional: lock / recents via accessibility

Android only allows "lock screen", "recents" and the notification shade fallback through an accessibility service.
nox ships one that listens to nothing and reads nothing (see `res/xml/accessibility.xml`), but it stays **off** until
you run `access`. On Android 13+ a sideloaded app needs: App info > nox > ⋮ > **Allow restricted settings** first.
Some banking apps refuse to run while any accessibility service is on, so only enable it if you want it.

## Project layout

```
app/src/main/java/app/nox/
  MainActivity.kt   the one screen: layout, insets, keyboard, gestures, scrollback
  Commands.kt       the shell: parser, aliases, completion, every command
  Fetch.kt          clock + fetch panel + dock renderer
  AppIndex.kt       app list (LauncherApps, incl. work profile), ranking, launching
  Fuzzy.kt          the matcher (pure Kotlin)       Calc.kt  the calculator (pure Kotlin)
  BigClock.kt       half-block clock font           Theme.kt  palettes
  Config.kt / Store.kt   settings / data (SharedPreferences)
  Sys.kt            battery, memory, storage, network, One UI version
  NoxAccess.kt      the optional accessibility service
```

Add a command in `Commands.kt` with one `reg("name", "group", "usage", "description") { x -> ... }` line.
Add a theme with one `Palette(...)` line in `Theme.kt`.

## Troubleshooting

* **Build fails:** open the failed run, copy the red error lines, that is all that is needed to fix it.
* **"App not installed" over an old version:** the old one was signed with a different key. Uninstall it once.
* **Suggestions look misaligned:** font failed to load. Check `app/src/main/assets/fonts/` is in the repo.
* **No apps listed:** run `reload`.

## Credits

Font: [JetBrains Mono](https://github.com/JetBrains/JetBrainsMono), SIL Open Font License 1.1.
