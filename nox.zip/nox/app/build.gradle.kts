plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// A fixed signing key lives in the repo so every CI build has the SAME signature.
// That is what lets a new APK install over the old one without uninstalling first.
// (Personal-use key. Swap in your own jks + passwords if you ever publish this.)
val noxKeystore = file("nox.jks")

android {
    namespace = "app.nox"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.nox"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }

    signingConfigs {
        if (noxKeystore.exists()) {
            create("nox") {
                storeFile = noxKeystore
                storeType = "jks"
                storePassword = "noxlauncher"
                keyAlias = "nox"
                keyPassword = "noxlauncher"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("nox") ?: signingConfigs.getByName("debug")
        }
        debug {
            signingConfig = signingConfigs.findByName("nox") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
// No dependencies on purpose: no AndroidX, no Compose, no network libs.
// The whole launcher is plain Android framework + Kotlin stdlib, ~150 KB of code.
