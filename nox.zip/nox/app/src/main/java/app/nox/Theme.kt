package app.nox

class Palette(
    val name: String,
    val fg: Int,
    val dim: Int,
    val accent: Int,
    val accent2: Int,
    val ok: Int,
    val warn: Int,
    val err: Int,
)

object Themes {
    private fun c(rgb: Int): Int = rgb or (0xFF shl 24)

    val all: List<Palette> = listOf(
        //                   fg            dim           accent        accent2       ok            warn          err
        Palette("void",    c(0xCDD1D6), c(0x5B6068), c(0x8BE9C8), c(0x7AA2F7), c(0x9ECE6A), c(0xE0AF68), c(0xF7768E)),
        Palette("matrix",  c(0xB8F5C8), c(0x24703C), c(0x00FF66), c(0x39D98A), c(0x00FF66), c(0xD7E04A), c(0xFF5F5F)),
        Palette("amber",   c(0xFFCF66), c(0x7A5A12), c(0xFFB000), c(0xFF8C00), c(0xB8D94A), c(0xFFD54A), c(0xFF6B4A)),
        Palette("ice",     c(0xC0CAF5), c(0x565F89), c(0x7DCFFF), c(0xBB9AF7), c(0x9ECE6A), c(0xE0AF68), c(0xF7768E)),
        Palette("rose",    c(0xE6D5DB), c(0x6E5A63), c(0xFF8FB1), c(0xC6A0F6), c(0xA6DA95), c(0xEED49F), c(0xED8796)),
        Palette("mono",    c(0xBDBDBD), c(0x555555), c(0xFFFFFF), c(0x9E9E9E), c(0xDDDDDD), c(0xBBBBBB), c(0x888888)),
        Palette("nord",    c(0xD8DEE9), c(0x4C566A), c(0x88C0D0), c(0x81A1C1), c(0xA3BE8C), c(0xEBCB8B), c(0xBF616A)),
        Palette("dracula", c(0xF8F8F2), c(0x6272A4), c(0xBD93F9), c(0xFF79C6), c(0x50FA7B), c(0xF1FA8C), c(0xFF5555)),
        Palette("gruvbox", c(0xEBDBB2), c(0x7C6F64), c(0xFABD2F), c(0xFE8019), c(0xB8BB26), c(0xFABD2F), c(0xFB4934)),
    )

    fun get(name: String): Palette = all.firstOrNull { it.name == name } ?: all[0]
}
