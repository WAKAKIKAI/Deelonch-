package app.nox

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.LinkMovementMethod
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/**
 * The whole launcher is this one screen:
 *
 *   [ scroll area:  big clock · fetch panel · dock · command output ]
 *   [ suggestions (fzf-style) ]
 *   [ ❯ prompt ]
 */
class MainActivity : Activity() {

    lateinit var cfg: Config
    lateinit var store: Store
    lateinit var apps: AppIndex
    lateinit var cmds: Commands

    /** how many monospace columns fit on screen (drives bar widths, clock choice, truncation) */
    var cols: Int = 44
        private set

    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var header: TextView
    private lateinit var outView: TextView
    private lateinit var suggView: TextView
    private lateinit var promptLabel: TextView
    private lateinit var input: EditText

    private val buf = SB()
    private val ui = Handler(Looper.getMainLooper())
    private var suggestions: List<Sug> = emptyList()
    private var flushPending = false
    private var stickBottom = false
    private var pendingKb = false
    private var pendingPerm: (() -> Unit)? = null
    private var histIdx = -1
    private var receiversOn = false
    private var downCanScrollUp = false
    private var downCanScrollDown = false

    // ───────────────────────────────────────── lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        cfg = Config(this)
        store = Store(this)
        apps = AppIndex(this, store)
        cmds = Commands(this)

        buildUi()
        applyConfig()
        immersive()
        apps.reload {
            renderHeader()
            refreshSuggestions()
        }
        if (!cfg.welcomed) {
            cmds.welcome()
            cfg.welcomed = true
        }
        if (cfg.kbd == "auto") pendingKb = true
    }

    override fun onResume() {
        super.onResume()
        immersive()
        registerReceivers()
        ui.removeCallbacks(tick)
        tick.run()
        if (!input.hasFocus()) input.requestFocus()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        unregisterReceivers()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) goHome()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            immersive()
            if (pendingKb) {
                pendingKb = false
                ui.postDelayed({ showKeyboard() }, 150)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyConfig()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (input.text.isNotEmpty()) input.setText("") else goHome()
    }

    /** Home button (or back with an empty prompt): fresh screen. */
    fun goHome() {
        clearOutput()
        input.setText("")
        histIdx = -1
        scroll.scrollTo(0, 0)
        renderHeader()
        hideKeyboard()
        if (cfg.kbd == "auto") {
            pendingKb = true
            if (hasWindowFocus()) {
                pendingKb = false
                ui.postDelayed({ showKeyboard() }, 150)
            }
        }
    }

    // ───────────────────────────────────────── ui construction
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun textView(): TextView = TextView(this).apply {
        includeFontPadding = false
        movementMethod = LinkMovementMethod.getInstance()
        fontFeatureSettings = "'liga' 0, 'calt' 0"
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        textDirection = View.TEXT_DIRECTION_LTR
    }

    private fun buildUi() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }

        clockView = textView()
        header = textView()
        outView = textView().apply { setPadding(0, dp(14), 0, 0) }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(10))
            addView(clockView, lp(match, wrap).apply { bottomMargin = dp(8) })
            addView(header, lp(match, wrap))
            addView(outView, lp(match, wrap))
        }

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content, ViewGroup.LayoutParams(match, wrap))
        }
        root.addView(scroll, lp(match, 0, 1f))

        suggView = textView().apply {
            visibility = View.GONE
            setPadding(0, dp(6), 0, dp(4))
        }
        root.addView(suggView, lp(match, wrap))

        promptLabel = textView().apply { setPadding(0, dp(8), 0, dp(8)) }
        input = EditText(this).apply {
            background = null
            setPadding(0, dp(8), 0, dp(8))
            includeFontPadding = false
            fontFeatureSettings = "'liga' 0, 'calt' 0"
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
            isLongClickable = true
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(promptLabel, lp(wrap, wrap))
            addView(input, lp(0, wrap, 1f))
            setOnClickListener { showKeyboard() }
        }
        root.addView(row, lp(match, wrap))

        setContentView(root)

        // edge-to-edge: we place everything ourselves (cutout + gesture bar + keyboard)
        root.setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            val side = dp(18)
            v.setPadding(bars.left + side, bars.top + dp(14), bars.right + side, max(bars.bottom, ime.bottom) + dp(10))
            WindowInsets.CONSUMED
        }
        root.requestApplyInsets()

        scroll.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol) measureCols()
            if (b - t != ob - ot && buf.isNotEmpty()) scrollToEnd()
        }
        outView.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (stickBottom && (b - t) != (ob - ot)) scrollToEnd()
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit()
                true
            } else {
                false
            }
        }
        input.setOnKeyListener { _, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (keyCode) {
                KeyEvent.KEYCODE_ENTER -> { submit(); true }
                KeyEvent.KEYCODE_TAB -> { suggestions.firstOrNull()?.let { fill(it.fill) }; true }
                KeyEvent.KEYCODE_DPAD_UP -> { recall(-1); true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { recall(1); true }
                else -> false
            }
        }
        input.addTextChangedListener(object : TextWatcher {
            private var prevLen = 0
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                prevLen = s?.length ?: 0
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                refreshSuggestions()
                if ((s?.length ?: 0) > prevLen) maybeAutolaunch()
            }
        })
    }

    /** (Re)apply every visual setting. Called after `set`, `theme` and on config changes. */
    fun applyConfig() {
        val p = cfg.pal
        val sz = cfg.size.toFloat()
        val hl = (p.accent and 0x00FFFFFF) or 0x44000000

        for (v in listOf(header, outView, suggView, promptLabel, input)) {
            v.typeface = Fonts.regular
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sz)
            v.setTextColor(p.fg)
            v.highlightColor = hl
        }
        header.setLineSpacing(0f, 1.2f)
        outView.setLineSpacing(0f, 1.2f)
        suggView.setLineSpacing(0f, 1.25f)

        clockView.typeface = Fonts.regular
        clockView.setTextColor(p.accent)
        clockView.setLineSpacing(0f, 1f) // block glyphs only tile seamlessly at exactly 1.0
        clockView.highlightColor = hl

        promptLabel.text = cfg.prompt + " "
        promptLabel.setTextColor(p.accent)
        input.setHintTextColor(p.dim)

        val cw = input.paint.measureText("M")
        input.textCursorDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor((p.accent and 0x00FFFFFF) or (0xB0 shl 24))
            setSize(if (cfg.cursor == "bar") dp(2) else max(cw.toInt(), dp(6)), -1)
        }

        var type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (cfg.strict) type = type or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        if (input.inputType != type) input.inputType = type
        input.imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_EXTRACT_UI or
            EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING or EditorInfo.IME_FLAG_NO_FULLSCREEN

        val bg = cfg.bg or (0xFF shl 24)
        if (cfg.wallpaper) {
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val alpha = cfg.dim.coerceIn(0, 100) * 255 / 100
            root.setBackgroundColor((bg and 0x00FFFFFF) or (alpha shl 24))
        } else {
            window.setBackgroundDrawable(ColorDrawable(bg))
            root.setBackgroundColor(bg)
        }

        measureCols()
        renderHeader()
        refreshSuggestions()
    }

    private fun immersive() {
        window.setDecorFitsSystemWindows(false)
        window.insetsController?.let {
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            it.hide(WindowInsets.Type.systemBars())
        }
    }

    private fun measureCols() {
        val w = scroll.width - scroll.paddingLeft - scroll.paddingRight
        if (w <= 0) return
        val cw = header.paint.measureText("M")
        if (cw <= 0f) return
        val c = (w / cw).toInt()
        if (c != cols) {
            cols = c
            renderHeader()
            renderSuggestions()
        }
    }

    // ───────────────────────────────────────── header (clock + fetch + dock)
    fun renderHeader() {
        if (!::header.isInitialized) return
        val clk = if (cfg.header) Fetch.clock(this, cols) else null
        if (clk == null) {
            clockView.visibility = View.GONE
        } else {
            val big = cfg.clock == "big" && cols >= BigClock.WIDTH + 2
            val scale = if (big) (cols / (BigClock.WIDTH + 4.0)).coerceIn(1.0, 1.6) else 2.0
            clockView.setTextSize(TypedValue.COMPLEX_UNIT_SP, (cfg.size * scale).toFloat())
            clockView.text = clk
            clockView.visibility = View.VISIBLE
        }
        val text: SB? = when {
            cfg.header -> Fetch.header(this, cols)
            cfg.dock -> SB().also { Fetch.dock(this, it) }
            else -> null
        }
        if (text == null) {
            header.visibility = View.GONE
        } else {
            header.text = text
            header.visibility = View.VISIBLE
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            renderHeader()
            ui.postDelayed(this, 60_000L - System.currentTimeMillis() % 60_000L + 40L)
        }
    }

    private val headerRun = Runnable { renderHeader() }
    private val reloadRun = Runnable {
        apps.reload {
            renderHeader()
            refreshSuggestions()
        }
    }

    private val battRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            ui.removeCallbacks(headerRun)
            ui.postDelayed(headerRun, 400)
        }
    }

    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            ui.removeCallbacks(reloadRun)
            ui.postDelayed(reloadRun, 1000)
        }
    }

    private fun registerReceivers() {
        if (receiversOn) return
        registerReceiver(battRx, IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        })
        registerReceiver(pkgRx, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        })
        receiversOn = true
    }

    private fun unregisterReceivers() {
        if (!receiversOn) return
        try {
            unregisterReceiver(battRx)
            unregisterReceiver(pkgRx)
        } catch (_: Throwable) {
        }
        receiversOn = false
    }

    // ───────────────────────────────────────── output
    /** Append to the scrollback. Batched: many calls in one frame cost one text update. */
    fun print(s: CharSequence) {
        buf.append(s)
        if (buf.length > 40_000) {
            buf.delete(0, buf.length - 30_000)
            val nl = buf.indexOf("\n")
            if (nl >= 0) buf.delete(0, nl + 1)
        }
        stickBottom = true
        if (!flushPending) {
            flushPending = true
            ui.post {
                flushPending = false
                outView.text = buf
            }
        }
    }

    fun echo(line: String) {
        val p = cfg.pal
        print(SB().put(cfg.prompt + " ", p.accent).put(line, p.fg).nl())
    }

    fun clearOutput() {
        buf.clear()
        buf.clearSpans()
        outView.text = ""
    }

    private fun scrollToEnd() {
        scroll.scrollTo(0, content.height)
        scroll.post { scroll.scrollTo(0, content.height) }
        stickBottom = false
    }

    // ───────────────────────────────────────── input
    fun fill(text: String) {
        input.setText(text)
        input.setSelection(input.text.length)
        showKeyboard()
    }

    fun showKeyboard() {
        input.requestFocus()
        input.post { getSystemService(InputMethodManager::class.java).showSoftInput(input, 0) }
    }

    private fun hideKeyboard() {
        getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun submit() {
        var line = input.text.toString().trim()
        if (line.isEmpty()) return
        val h = store.history
        if (line == "!!") {
            line = h.lastOrNull() ?: return
        } else if (line.length > 1 && line[0] == '!' && line.substring(1).all { it.isDigit() }) {
            line = line.substring(1).toIntOrNull()?.let { h.getOrNull(it - 1) } ?: line
        }
        input.setText("")
        histIdx = -1
        store.pushHistory(line)
        echo(line)
        cmds.exec(line)
    }

    /** hardware keyboard up/down */
    private fun recall(dir: Int) {
        val h = store.history
        if (h.isEmpty()) return
        histIdx = if (dir < 0) {
            if (histIdx < 0) h.size - 1 else max(0, histIdx - 1)
        } else {
            if (histIdx < 0) return
            histIdx + 1
        }
        if (histIdx >= h.size) {
            histIdx = -1
            input.setText("")
            return
        }
        input.setText(h[histIdx])
        input.setSelection(input.text.length)
    }

    private fun maybeAutolaunch() {
        if (!cfg.autolaunch) return
        val q = input.text.toString().trim()
        val only = suggestions.singleOrNull() ?: return
        if (q.length >= 2 && only.tag == "app" && !q.contains(' ')) {
            input.setText("")
            only.run()
        }
    }

    // ───────────────────────────────────────── suggestions (fzf-style list above the prompt)
    fun refreshSuggestions() {
        if (!::input.isInitialized) return
        val q = input.text.toString()
        suggestions = if (q.isBlank()) emptyList() else cmds.complete(q)
        renderSuggestions()
    }

    private fun renderSuggestions() {
        if (!::suggView.isInitialized) return
        val p = cfg.pal
        if (suggestions.isEmpty()) {
            suggView.text = ""
            suggView.visibility = View.GONE
            return
        }
        val tagW = 5
        val room = (cols - 2 - 1 - tagW).coerceAtLeast(10)
        val sb = SB()
        suggestions.forEachIndexed { i, s ->
            val start = sb.length
            val top = i == 0
            sb.put(if (top) "▸ " else "  ", if (top) p.accent else p.dim)
            val label = if (s.text.length > room) s.text.take(room - 1) + "…" else s.text
            val hl = s.hl.toHashSet()
            for ((k, ch) in label.withIndex()) {
                val lit = k in hl
                sb.put(ch.toString(), if (lit) p.accent else s.color, bold = lit)
            }
            sb.put(" ".repeat((room - label.length).coerceAtLeast(1)), p.fg)
            sb.put(s.tag, p.dim)
            sb.clickable(start, sb.length) { s.pick() }
            if (i < suggestions.size - 1) sb.nl()
        }
        suggView.text = sb
        suggView.visibility = View.VISIBLE
    }

    // ───────────────────────────────────────── gestures: swipe down = notifications, swipe up = keyboard
    private val gestures: GestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (abs(dy) < dp(110) || abs(dy) < abs(dx) * 1.8f || abs(velocityY) < 900f) return false
                if (dy > 0 && !downCanScrollUp) {
                    cmds.shade(false)
                    return true
                }
                if (dy < 0 && !downCanScrollDown) {
                    showKeyboard()
                    return true
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            downCanScrollUp = scroll.canScrollVertically(-1)
            downCanScrollDown = scroll.canScrollVertically(1)
        }
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ───────────────────────────────────────── runtime permissions (contacts for `call <name>`)
    fun withPermission(perm: String, onGranted: () -> Unit) {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
            return
        }
        pendingPerm = onGranted
        requestPermissions(arrayOf(perm), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val cb = pendingPerm
        pendingPerm = null
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            cb?.invoke()
        } else {
            print(SB().put("permission denied", cfg.pal.err).nl())
        }
    }
}
