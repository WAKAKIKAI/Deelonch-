package app.nox

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Optional. It exists for exactly one reason: Android only lets an accessibility service perform
 * "global actions" (lock screen, open notifications / quick settings / recents). It subscribes to
 * no events and reads no screen content (see res/xml/accessibility.xml).
 */
class NoxAccess : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: NoxAccess? = null
    }
}
