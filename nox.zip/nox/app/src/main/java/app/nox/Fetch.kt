package app.nox

import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Renders the home panel: big clock + a tiny "fastfetch". Also used by the `fetch` command. */
object Fetch {

    val KNOWN_FIELDS = listOf("os", "device", "soc", "screen", "kernel", "uptime", "apps", "net", "theme", "shell", "time", "battery", "memory", "storage")

    fun is24(a: MainActivity): Boolean = when (a.cfg.hour) {
        "12" -> false
        "24" -> true
        else -> DateFormat.is24HourFormat(a)
    }

    fun hhmm(a: MainActivity, d: Date = Date()): String {
        val c = Calendar.getInstance().apply { time = d }
        val m = String.format(Locale.ENGLISH, "%02d", c.get(Calendar.MINUTE))
        return if (is24(a)) {
            String.format(Locale.ENGLISH, "%02d:%s", c.get(Calendar.HOUR_OF_DAY), m)
        } else {
            val h = c.get(Calendar.HOUR).let { if (it == 0) 12 else it }
            "$h:$m"
        }
    }

    fun dateLine(a: MainActivity, d: Date = Date()): String {
        var s = SimpleDateFormat("EEEE '·' dd MMMM yyyy", Locale.ENGLISH).format(d)
        if (!is24(a)) {
            val pm = Calendar.getInstance().apply { time = d }.get(Calendar.AM_PM) == Calendar.PM
            s += if (pm) " · pm" else " · am"
        }
        return s
    }

    /** The big (or small) clock, or null when `set clock off`. */
    fun clock(a: MainActivity, cols: Int): SB? {
        val p = a.cfg.pal
        if (a.cfg.clock == "off") return null
        val t = hhmm(a)
        val sb = SB()
        if (a.cfg.clock == "big" && cols >= BigClock.WIDTH + 2) {
            val rows = BigClock.render(t)
            rows.forEachIndexed { i, r ->
                sb.put(r, p.accent)
                if (i < rows.size - 1) sb.nl()
            }
        } else {
            sb.put(t, p.accent, bold = true)
        }
        return sb
    }

    private fun trunc(s: String, n: Int): String = if (n < 2 || s.length <= n) s else s.take(n - 1) + "…"

    private fun level(frac: Double, p: Palette): Int = when {
        frac < 0.70 -> p.ok
        frac < 0.88 -> p.warn
        else -> p.err
    }

    /** date, user@host, the configured fields, colour strip, and (optionally) dock + todos. */
    fun header(a: MainActivity, cols: Int, withExtras: Boolean = true): SB {
        val cfg = a.cfg
        val p = cfg.pal
        val sb = SB()

        sb.put(dateLine(a), p.dim).nl(2)
        sb.put(cfg.user, p.accent, bold = true).put("@", p.dim).put(cfg.host, p.accent2, bold = true).nl()
        sb.put("─".repeat((cfg.user.length + cfg.host.length + 1).coerceAtLeast(4)), p.dim).nl()

        val barCells = (cols - 9 - 1 - 17).coerceIn(6, 12)
        fun kv(key: String, value: String) {
            sb.put(key.padEnd(9), p.accent).put(value, p.fg).nl()
        }
        fun meter(key: String, frac: Double, color: Int, text: String) {
            sb.put(key.padEnd(9), p.accent).bar(frac, barCells, color, p.dim).put("  ").put(text, p.fg).nl()
        }

        for (f in cfg.fields.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }) {
            when (f) {
                "os" -> kv("os", Sys.os())
                "device" -> kv("device", Sys.device())
                "soc" -> kv("soc", Sys.soc())
                "screen" -> kv("screen", Sys.screen(a))
                "kernel" -> kv("kernel", Sys.kernel())
                "uptime" -> kv("uptime", Sys.uptime())
                "net" -> kv("net", Sys.net(a))
                "theme" -> kv("theme", cfg.theme)
                "shell" -> kv("shell", "nox ${Sys.version(a)}")
                "time" -> kv("time", hhmm(a).trim() + " · " + SimpleDateFormat("EEE dd MMM", Locale.ENGLISH).format(Date()))
                "apps" -> {
                    val hid = a.store.hidden.size
                    kv("apps", "${a.apps.all.size - hid}" + if (hid > 0) " · $hid hidden" else "")
                }
                "battery" -> {
                    val b = Sys.battery(a)
                    val frac = b.pct / 100.0
                    val col = when {
                        b.charging || b.full -> p.ok
                        b.pct >= 50 -> p.ok
                        b.pct >= 20 -> p.warn
                        else -> p.err
                    }
                    val note = when {
                        b.charging -> " · charging"
                        b.full -> " · full"
                        b.onPower -> " · plugged"
                        else -> ""
                    }
                    meter("battery", frac, col, "${b.pct}%$note")
                }
                "memory" -> {
                    val (u, t) = Sys.memory(a)
                    val frac = if (t > 0) u.toDouble() / t else 0.0
                    meter("memory", frac, level(frac, p), "${Sys.gib(u)} / ${Sys.gib(t)}")
                }
                "storage" -> {
                    val (u, t) = Sys.storage(a)
                    val frac = if (t > 0) u.toDouble() / t else 0.0
                    meter("storage", frac, level(frac, p), "${Sys.gb(u)} / ${Sys.gb(t)}")
                }
            }
        }

        sb.nl()
        for (c in listOf(p.accent, p.accent2, p.ok, p.warn, p.err, p.fg, p.dim)) sb.put("███", c)

        if (withExtras) {
            if (cfg.dock) {
                sb.nl(2)
                dock(a, sb)
            }
            val todos = a.store.todos
            if (cfg.todos > 0 && todos.isNotEmpty()) {
                sb.nl(2).put("todo", p.accent, bold = true)
                for (t in todos.takeLast(cfg.todos)) {
                    sb.nl().put("› ", p.dim).put(trunc(t, cols - 2), p.fg)
                }
            }
        }
        return sb
    }

    /** [phone] [messages] [camera] ...  every item is tappable */
    fun dock(a: MainActivity, sb: SB) {
        val p = a.cfg.pal
        val items = a.cmds.dockItems()
        for ((i, item) in items.withIndex()) {
            if (i > 0) sb.put("  ", p.dim)
            val go = { a.cmds.launch(item) }
            sb.put("[", p.dim, onClick = go)
                .put(item.label.lowercase().nb(), p.accent2, onClick = go)
                .put("]", p.dim, onClick = go)
        }
    }
}
