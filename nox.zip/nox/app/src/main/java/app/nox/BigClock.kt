package app.nox

/**
 * 3-row clock drawn with half-block characters (▀ ▄ █) from a 3x5 pixel font.
 * Each pixel is 2 columns wide; two pixel rows share one text row.
 * JetBrains Mono's block glyphs span the full line height, so rows tile seamlessly.
 */
object BigClock {
    const val WIDTH = 34 // columns for "HH:MM"

    private val G: Map<Char, Array<String>> = mapOf(
        '0' to arrayOf("###", "#.#", "#.#", "#.#", "###"),
        '1' to arrayOf(".#.", "##.", ".#.", ".#.", "###"),
        '2' to arrayOf("###", "..#", "###", "#..", "###"),
        '3' to arrayOf("###", "..#", "###", "..#", "###"),
        '4' to arrayOf("#.#", "#.#", "###", "..#", "..#"),
        '5' to arrayOf("###", "#..", "###", "..#", "###"),
        '6' to arrayOf("###", "#..", "###", "#.#", "###"),
        '7' to arrayOf("###", "..#", "..#", "..#", "..#"),
        '8' to arrayOf("###", "#.#", "###", "#.#", "###"),
        '9' to arrayOf("###", "#.#", "###", "..#", "###"),
        ':' to arrayOf(".", "#", ".", "#", "."),
        ' ' to arrayOf("...", "...", "...", "...", "..."),
    )

    fun render(text: String): List<String> {
        val rows = Array(3) { StringBuilder() }
        for ((n, ch) in text.withIndex()) {
            val g = G[ch] ?: G[' ']!!
            if (n > 0) rows.forEach { it.append("  ") }
            for (c in g[0].indices) {
                fun px(r: Int) = r in 0..4 && g[r][c] == '#'
                for (t in 0..2) {
                    val top = px(2 * t - 1)
                    val bot = px(2 * t)
                    val chr = when {
                        top && bot -> '█'
                        top -> '▀'
                        bot -> '▄'
                        else -> ' '
                    }
                    rows[t].append(chr).append(chr)
                }
            }
        }
        return rows.map { it.toString() }
    }
}
