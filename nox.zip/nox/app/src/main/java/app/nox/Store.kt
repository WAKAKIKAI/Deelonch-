package app.nox

import android.content.Context

/** Persistent data: dock, hidden apps, aliases, todos, history, launch counts. Plain newline-separated text in SharedPreferences. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nox_data", Context.MODE_PRIVATE)

    private fun read(k: String): MutableList<String> {
        val s = sp.getString(k, null) ?: return ArrayList()
        return s.split('\n').filter { it.isNotEmpty() }.toMutableList()
    }

    private fun write(k: String, l: List<String>) {
        sp.edit().putString(k, l.joinToString("\n")).apply()
    }

    private fun clean(s: String) = s.replace('\n', ' ').replace('\t', ' ').trim()

    // ---- dock (ids like "app:pkg/cls" or "sys:phone")
    var dock: List<String>
        get() = if (sp.contains("dock")) read("dock") else DEFAULT_DOCK
        set(v) = write("dock", v)

    fun resetDock() {
        sp.edit().remove("dock").apply()
    }

    // ---- hidden apps
    val hidden: Set<String> get() = read("hidden").toSet()

    fun hide(id: String) {
        val l = read("hidden"); if (id !in l) { l.add(id); write("hidden", l) }
    }

    fun unhide(id: String) {
        val l = read("hidden"); if (l.remove(id)) write("hidden", l)
    }

    // ---- aliases (name \t expansion)
    val aliases: Map<String, String>
        get() {
            val m = LinkedHashMap<String, String>()
            for (l in read("aliases")) {
                val i = l.indexOf('\t')
                if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
            }
            return m
        }

    fun setAlias(name: String, value: String) {
        val m = LinkedHashMap(aliases)
        m[name] = clean(value)
        write("aliases", m.map { "${it.key}\t${it.value}" })
    }

    fun removeAlias(name: String): Boolean {
        val m = LinkedHashMap(aliases)
        if (m.remove(name) == null) return false
        write("aliases", m.map { "${it.key}\t${it.value}" })
        return true
    }

    // ---- todos
    var todos: List<String>
        get() = read("todos")
        set(v) = write("todos", v.map { clean(it) }.filter { it.isNotEmpty() })

    // ---- history
    val history: List<String> get() = read("history")

    fun pushHistory(line: String) {
        val l = clean(line)
        if (l.isEmpty()) return
        val h = read("history")
        if (h.lastOrNull() == l) return
        h.add(l)
        while (h.size > 200) h.removeAt(0)
        write("history", h)
    }

    // ---- launch counts (drive ranking)
    private val usage: MutableMap<String, Int> = HashMap<String, Int>().also { m ->
        for (l in read("usage")) {
            val i = l.lastIndexOf('=')
            if (i > 0) l.substring(i + 1).toIntOrNull()?.let { m[l.substring(0, i)] = it }
        }
    }

    fun uses(id: String): Int = usage[id] ?: 0

    fun bump(id: String) {
        usage[id] = uses(id) + 1
        write("usage", usage.map { "${it.key}=${it.value}" })
    }

    fun top(n: Int): List<Pair<String, Int>> =
        usage.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }

    companion object {
        val DEFAULT_DOCK = listOf("sys:phone", "sys:sms", "sys:camera", "sys:web", "sys:settings")
    }
}
