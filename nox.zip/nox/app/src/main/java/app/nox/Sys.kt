package app.nox

import android.app.Activity
import android.app.ActivityManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings
import java.util.Locale

/** Read-only device facts for the fetch panel and the info commands. */
object Sys {

    class Batt(
        val pct: Int,
        val status: Int,
        val plugged: Int,
        val tempC: Float,
        val mv: Int,
        val health: Int,
    ) {
        val charging get() = status == BatteryManager.BATTERY_STATUS_CHARGING
        val full get() = status == BatteryManager.BATTERY_STATUS_FULL
        val onPower get() = plugged != 0
    }

    fun battery(ctx: Context): Batt {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level < 0 || scale <= 0) 0 else (level * 100 / scale)
        return Batt(
            pct,
            i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1,
            i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0,
            (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
            i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0,
            i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0,
        )
    }

    /** Milliseconds until full while charging, or -1 when unknown. */
    fun chargeEtaMs(ctx: Context): Long = try {
        ctx.getSystemService(BatteryManager::class.java).computeChargeTimeRemaining()
    } catch (_: Throwable) {
        -1L
    }

    fun healthText(h: Int): String = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "over-voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "cold"
        else -> "unknown"
    }

    fun plugText(p: Int): String = when {
        p and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "wireless"
        p and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "usb"
        p and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "ac"
        else -> "none"
    }

    /** used, total (bytes) */
    fun memory(ctx: Context): Pair<Long, Long> {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return Pair(mi.totalMem - mi.availMem, mi.totalMem)
    }

    /** used, total (bytes) — total is the marketing capacity (256 GB), like the Settings app shows. */
    fun storage(ctx: Context): Pair<Long, Long> = try {
        val ssm = ctx.getSystemService(StorageStatsManager::class.java)
        val total = ssm.getTotalBytes(StorageManager.UUID_DEFAULT)
        val free = ssm.getFreeBytes(StorageManager.UUID_DEFAULT)
        Pair(total - free, total)
    } catch (_: Throwable) {
        val st = StatFs(Environment.getDataDirectory().path)
        Pair(st.totalBytes - st.availableBytes, st.totalBytes)
    }

    fun gib(b: Long): String = String.format(Locale.ENGLISH, "%.1fG", b / 1073741824.0)
    fun gb(b: Long): String = String.format(Locale.ENGLISH, "%.0fG", b / 1e9)

    fun duration(totalSec: Long): String {
        val d = totalSec / 86400
        val h = (totalSec % 86400) / 3600
        val m = (totalSec % 3600) / 60
        return when {
            d > 0 -> "${d}d ${h}h ${m}m"
            h > 0 -> "${h}h ${m}m"
            else -> "${m}m"
        }
    }

    fun uptime(): String = duration(SystemClock.elapsedRealtime() / 1000)

    fun net(ctx: Context): String {
        val airplane = try {
            Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Throwable) {
            false
        }
        return try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val n = cm.activeNetwork ?: return if (airplane) "airplane mode" else "offline"
            val c = cm.getNetworkCapabilities(n) ?: return "offline"
            val parts = ArrayList<String>()
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) parts.add("wifi")
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) parts.add("mobile")
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) parts.add("ethernet")
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH)) parts.add("bluetooth")
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) parts.add("vpn")
            var s = if (parts.isEmpty()) "connected" else parts.joinToString(" + ")
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) s += " (no internet)"
            s
        } catch (_: Throwable) {
            "unknown"
        }
    }

    /** Samsung One UI version via the vendor field, e.g. "7.0". Null on non-Samsung phones. */
    fun oneUi(): String? = try {
        val v = Build.VERSION::class.java.getDeclaredField("SEM_PLATFORM_INT").getInt(null)
        if (v < 100000) null else {
            val x = v - 90000
            "${x / 10000}.${(x % 10000) / 100}"
        }
    } catch (_: Throwable) {
        null
    }

    fun os(): String {
        val ui = oneUi()
        return "Android ${Build.VERSION.RELEASE}" + if (ui != null) " · One UI $ui" else ""
    }

    fun device(): String {
        val man = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        return if (Build.MODEL.startsWith(Build.MANUFACTURER, ignoreCase = true)) Build.MODEL else "$man ${Build.MODEL}"
    }

    fun soc(): String {
        if (Build.VERSION.SDK_INT >= 31) {
            val m = Build.SOC_MODEL
            val v = Build.SOC_MANUFACTURER
            if (m.isNotBlank() && m != Build.UNKNOWN) {
                return if (v.isNotBlank() && v != Build.UNKNOWN) "$v $m" else m
            }
        }
        return Build.HARDWARE
    }

    fun kernel(): String = (System.getProperty("os.version") ?: "?").substringBefore('-')

    fun kernelFull(): String = System.getProperty("os.version") ?: "?"

    fun screen(ctx: Context): String {
        val dm = ctx.resources.displayMetrics
        val hz = try {
            (ctx as? Activity)?.display?.refreshRate?.let { Math.round(it) }
        } catch (_: Throwable) {
            null
        }
        return "${dm.widthPixels}x${dm.heightPixels}" + (if (hz != null) " · ${hz}Hz" else "") + " · ${dm.densityDpi}dpi"
    }

    fun version(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (_: Throwable) {
        "?"
    }
}
