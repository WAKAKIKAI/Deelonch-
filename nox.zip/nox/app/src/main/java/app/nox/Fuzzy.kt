package app.nox

/** A successful match: higher [score] is better, [idx] are the matched character positions (for highlighting). */
class Match(val score: Int, val idx: IntArray)

/**
 * The matcher behind every suggestion. Tiers (score ranges):
 *   1000        exact
 *   ~900        prefix            "chr"  -> "chrome"
 *   ~800        word prefix       "store" -> "play store"
 *   ~750        multi-word prefix "play st" -> "play store"
 *   700         acronym           "gm" -> "google maps"
 *   ~600        substring
 *   100..499    subsequence       "cmra" -> "camera"
 */
object Fuzzy {

    /** Lowercase + every non-alphanumeric becomes a space. Length preserving, so indices map back to the original. */
    fun fold(s: String): String {
        val c = CharArray(s.length)
        for (i in s.indices) {
            val ch = s[i]
            c[i] = if (ch.isLetterOrDigit()) ch.lowercaseChar() else ' '
        }
        return String(c)
    }

    fun clean(q: String): String = fold(q).trim().replace(Regex(" +"), " ")

    private fun range(from: Int, len: Int) = IntArray(len) { from + it }

    fun match(rawQuery: String, label: String): Match? {
        val q = clean(rawQuery)
        if (q.isEmpty()) return null
        val t = fold(label)
        if (t.isBlank()) return null

        if (t == q) return Match(1000, range(0, q.length))
        if (t.startsWith(q)) return Match(900 - minOf(t.length - q.length, 99), range(0, q.length))

        // occurrence of q at a word boundary (word prefix), remembering the first plain substring too
        var firstSub = -1
        var i = t.indexOf(q)
        while (i >= 0) {
            if (i == 0 || t[i - 1] == ' ') return Match(800 - minOf(i, 99), range(i, q.length))
            if (firstSub < 0) firstSub = i
            i = t.indexOf(q, i + 1)
        }

        if (q.contains(' ')) tokenMatch(q, t)?.let { return it }

        if (q.length >= 2 && !q.contains(' ')) acronym(q, t)?.let { return it }

        if (firstSub >= 0) return Match(600 - minOf(firstSub, 99), range(firstSub, q.length))

        return subsequence(q, t)
    }

    /** every query token must be the prefix of a distinct word of the target */
    private fun tokenMatch(q: String, t: String): Match? {
        val starts = wordStarts(t)
        val used = HashSet<Int>()
        val idx = ArrayList<Int>()
        for (tok in q.split(' ')) {
            val w = starts.firstOrNull { it !in used && t.startsWith(tok, it) } ?: return null
            used.add(w)
            for (k in tok.indices) idx.add(w + k)
        }
        return Match(750, idx.toIntArray())
    }

    private fun wordStarts(t: String): List<Int> {
        val out = ArrayList<Int>()
        for (i in t.indices) if (t[i] != ' ' && (i == 0 || t[i - 1] == ' ')) out.add(i)
        return out
    }

    private fun acronym(q: String, t: String): Match? {
        val starts = wordStarts(t)
        if (q.length > starts.size) return null
        val idx = IntArray(q.length)
        for (k in q.indices) {
            if (t[starts[k]] != q[k]) return null
            idx[k] = starts[k]
        }
        return Match(700, idx)
    }

    private fun subsequence(q: String, t: String): Match? {
        val qc = q.replace(" ", "")
        if (qc.length < 2) return null
        val idx = IntArray(qc.length)
        var from = 0
        for (k in qc.indices) {
            val f = t.indexOf(qc[k], from)
            if (f < 0) return null
            idx[k] = f
            from = f + 1
        }
        var score = 300
        for (k in idx.indices) {
            if (k > 0 && idx[k] == idx[k - 1] + 1) score += 12
            if (idx[k] == 0 || t[idx[k] - 1] == ' ') score += 10
        }
        score -= minOf(idx.last() - idx.first() - (qc.length - 1), 100)
        return Match(score.coerceIn(100, 499), idx)
    }

    /** Levenshtein distance, used for "did you mean". */
    fun distance(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }
}
