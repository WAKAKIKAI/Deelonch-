package app.nox

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.TypefaceSpan
import android.view.View
import kotlin.math.roundToInt

typealias SB = SpannableStringBuilder

/** JetBrains Mono (bundled, SIL OFL). Falls back to the system monospace if the asset is ever missing. */
object Fonts {
    var regular: Typeface = Typeface.MONOSPACE
    var bold: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun init(ctx: Context) {
        regular = load(ctx, "fonts/JetBrainsMono-Regular.ttf", regular)
        bold = load(ctx, "fonts/JetBrainsMono-Bold.ttf", bold)
    }

    private fun load(ctx: Context, path: String, fallback: Typeface): Typeface =
        try {
            Typeface.createFromAsset(ctx.assets, path)
        } catch (_: Throwable) {
            fallback
        }
}

/** Append text with no styling of its own. */
fun SB.put(text: CharSequence): SB {
    append(text)
    return this
}

/** Append coloured (optionally bold / tappable) text. */
fun SB.put(text: CharSequence, color: Int, bold: Boolean = false, onClick: (() -> Unit)? = null): SB {
    if (text.isEmpty()) return this
    val s = length
    append(text)
    val e = length
    setSpan(ForegroundColorSpan(color), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    if (bold) setSpan(TypefaceSpan(Fonts.bold), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    if (onClick != null) clickable(s, e, onClick)
    return this
}

/** Make [start, end) tappable without touching its colours. */
fun SB.clickable(start: Int, end: Int, action: () -> Unit): SB {
    setSpan(object : ClickableSpan() {
        override fun onClick(widget: View) = action()
        override fun updateDrawState(ds: TextPaint) {
            ds.isUnderlineText = false // keep whatever colour the other spans chose
        }
    }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    return this
}

fun SB.nl(n: Int = 1): SB {
    repeat(n) { append('\n') }
    return this
}

/** ━━━━━━────  filled part in [on], remainder in [off]. */
fun SB.bar(frac: Double, cells: Int, on: Int, off: Int): SB {
    val n = (frac.coerceIn(0.0, 1.0) * cells).roundToInt()
    put("━".repeat(n), on)
    put("─".repeat(cells - n), off)
    return this
}

/** Spaces -> no-break spaces so labels never wrap in the middle. */
fun String.nb(): String = replace(' ', '\u00A0')
