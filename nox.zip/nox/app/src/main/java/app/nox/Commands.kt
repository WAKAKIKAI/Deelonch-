package app.nox

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One entry in the suggestion list above the prompt. */
class Sug(
    val text: String,
    val tag: String,
    val color: Int,
    val hl: IntArray,
    val fill: String,        // what TAB / a tap on a non-app puts in the prompt
    val pick: () -> Unit,    // tap
    val run: () -> Unit,     // ENTER
)

enum class ArgKind { NONE, APP, HIDDEN_APP, DOCK, LIST }

class Cmd(
    val name: String,
    val group: String,
    val usage: String,
    val desc: String,
    val aliases: List<String>,
    val arg: ArgKind,
    val options: ((String) -> List<String>)?,
    val hidden: Boolean,
    val run: (Args) -> Unit,
)

class Args(val raw: String) {
    val list: List<String> = tokenize(raw)
    val first: String get() = list.firstOrNull() ?: ""
    fun flag(f: String): Boolean = list.contains(f)
    val noFlags: String get() = list.filter { !it.startsWith("-") }.joinToString(" ")
}

private fun opensQuote(s: String, i: Int): Boolean {
    val ch = s[i]
    return (ch == '"' || ch == '\'') && (i == 0 || s[i - 1].isWhitespace() || s[i - 1] == '=')
}

/** Shell-style words. Quotes only open at the start of a word, so "don't" keeps its apostrophe. */
fun tokenize(s: String): List<String> {
    val out = ArrayList<String>()
    val cur = StringBuilder()
    var q = '\u0000'
    var has = false
    for (i in s.indices) {
        val ch = s[i]
        when {
            q != '\u0000' -> if (ch == q) q = '\u0000' else cur.append(ch)
            opensQuote(s, i) -> { q = ch; has = true }
            ch.isWhitespace() -> if (cur.isNotEmpty() || has) { out.add(cur.toString()); cur.setLength(0); has = false }
            else -> cur.append(ch)
        }
    }
    if (cur.isNotEmpty() || has) out.add(cur.toString())
    return out
}

/** Split `a; b; c` into commands, ignoring `;` inside quotes. */
fun splitCommands(s: String): List<String> {
    val out = ArrayList<String>()
    val cur = StringBuilder()
    var q = '\u0000'
    for (i in s.indices) {
        val ch = s[i]
        when {
            q != '\u0000' -> { cur.append(ch); if (ch == q) q = '\u0000' }
            opensQuote(s, i) -> { q = ch; cur.append(ch) }
            ch == ';' -> { out.add(cur.toString()); cur.setLength(0) }
            else -> cur.append(ch)
        }
    }
    out.add(cur.toString())
    return out
}

private fun unquote(s: String): String =
    if (s.length >= 2 && (s.first() == '"' || s.first() == '\'') && s.last() == s.first()) s.substring(1, s.length - 1) else s

private class Opt(val key: String, val desc: String, val values: List<String>?, val get: () -> String, val set: (String) -> String?)

class Commands(private val a: MainActivity) {
    private val cfg get() = a.cfg
    private val store get() = a.store
    private val apps get() = a.apps
    private val p get() = a.cfg.pal

    private val list = ArrayList<Cmd>()
    private val byName = HashMap<String, Cmd>()

    private val urlRx = Regex("^(https?://\\S+|([a-z0-9-]+\\.)+[a-z]{2,}(:\\d+)?(/\\S*)?)$", RegexOption.IGNORE_CASE)
    private val alarmRx = Regex("^(\\d{1,2})(?::?(\\d{2}))?\\s*(am|pm)?$", RegexOption.IGNORE_CASE)

    private val engines = linkedMapOf(
        "ddg" to "https://duckduckgo.com/?q=",
        "google" to "https://www.google.com/search?q=",
        "brave" to "https://search.brave.com/search?q=",
        "startpage" to "https://www.startpage.com/do/search?q=",
        "bing" to "https://www.bing.com/search?q=",
    )

    private val sections = linkedMapOf(
        "wifi" to Settings.ACTION_WIFI_SETTINGS,
        "bt" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "display" to Settings.ACTION_DISPLAY_SETTINGS,
        "sound" to Settings.ACTION_SOUND_SETTINGS,
        "battery" to Intent.ACTION_POWER_USAGE_SUMMARY,
        "optimize" to Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS,
        "storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        "apps" to Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS,
        "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "date" to Settings.ACTION_DATE_SETTINGS,
        "lang" to Settings.ACTION_LOCALE_SETTINGS,
        "keyboard" to Settings.ACTION_INPUT_METHOD_SETTINGS,
        "access" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        "home" to Settings.ACTION_HOME_SETTINGS,
        "default" to Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS,
        "dev" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
        "about" to Settings.ACTION_DEVICE_INFO_SETTINGS,
        "nfc" to Settings.ACTION_NFC_SETTINGS,
        "airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "vpn" to Settings.ACTION_VPN_SETTINGS,
        "privacy" to Settings.ACTION_PRIVACY_SETTINGS,
        "security" to Settings.ACTION_SECURITY_SETTINGS,
    )

    private var torchOn = false

    private val validBgError = "use a hex colour like #000000 (or: black)"

    private val opts: List<Opt> = listOf(
        enumOpt("theme", "color theme", Themes.all.map { it.name }, { cfg.theme }) { cfg.theme = it },
        textOpt("bg", "background colour (hex)", { String.format("#%06X", cfg.bg and 0xFFFFFF) }) { v ->
            try {
                cfg.bg = if (v.equals("black", true)) Color.BLACK else (Color.parseColor(v) or (0xFF shl 24))
                null
            } catch (_: Throwable) {
                validBgError
            }
        },
        intOpt("size", "font size in sp", 9..24, { cfg.size }) { cfg.size = it },
        enumOpt("clock", "big | small | off", listOf("big", "small", "off"), { cfg.clock }) { cfg.clock = it },
        enumOpt("hour", "auto | 12 | 24", listOf("auto", "12", "24"), { cfg.hour }) { cfg.hour = it },
        onOff("header", "show the fetch panel", { cfg.header }) { cfg.header = it },
        onOff("dock", "show the [pinned] row", { cfg.dock }) { cfg.dock = it },
        textOpt("fields", "panel fields, comma separated", { cfg.fields.ifEmpty { "none" } }) { v ->
            if (v.equals("none", true)) {
                cfg.fields = ""
                null
            } else {
                val f = v.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
                val bad = f.firstOrNull { it !in Fetch.KNOWN_FIELDS }
                if (bad != null) "unknown field '$bad'. known: ${Fetch.KNOWN_FIELDS.joinToString(",")}" else { cfg.fields = f.joinToString(","); null }
            }
        },
        intOpt("todos", "todos shown on home (0 = none)", 0..10, { cfg.todos }) { cfg.todos = it },
        enumOpt("kbd", "auto | manual  (keyboard on home)", listOf("auto", "manual"), { cfg.kbd }) { cfg.kbd = it },
        onOff("autolaunch", "launch when only one app matches", { cfg.autolaunch }) { cfg.autolaunch = it },
        onOff("strict", "hard no-autocorrect keyboard", { cfg.strict }) { cfg.strict = it },
        enumOpt("cursor", "block | bar", listOf("block", "bar"), { cfg.cursor }) { cfg.cursor = it },
        onOff("wallpaper", "show system wallpaper", { cfg.wallpaper }) { cfg.wallpaper = it },
        intOpt("dim", "wallpaper darkening 0-100", 0..100, { cfg.dim }) { cfg.dim = it },
        enumOpt("engine", "default web search", engines.keys.toList(), { cfg.engine }) { cfg.engine = it },
        textOpt("prompt", "prompt symbol", { cfg.prompt }) { cfg.prompt = it; null },
        textOpt("user", "name in user@host", { cfg.user }) { cfg.user = it.replace(' ', '_'); null },
        textOpt("host", "host in user@host", { cfg.host }) { cfg.host = it.replace(' ', '_'); null },
    )

    private fun enumOpt(key: String, desc: String, values: List<String>, get: () -> String, set: (String) -> Unit) =
        Opt(key, desc, values, get) { v ->
            val x = v.lowercase()
            if (x in values) { set(x); null } else "one of: ${values.joinToString(" ")}"
        }

    private fun onOff(key: String, desc: String, get: () -> Boolean, set: (Boolean) -> Unit) =
        Opt(key, desc, listOf("on", "off"), { if (get()) "on" else "off" }) { v ->
            when (v.lowercase()) {
                "on", "true", "yes", "1" -> { set(true); null }
                "off", "false", "no", "0" -> { set(false); null }
                else -> "use on or off"
            }
        }

    private fun intOpt(key: String, desc: String, range: IntRange, get: () -> Int, set: (Int) -> Unit) =
        Opt(key, desc, null, { get().toString() }) { v ->
            val n = v.toIntOrNull()
            if (n != null && n in range) { set(n); null } else "a number from ${range.first} to ${range.last}"
        }

    private fun textOpt(key: String, desc: String, get: () -> String, set: (String) -> String?) =
        Opt(key, desc, null, get) { v -> set(v) }

    // ───────────────────────── output helpers
    private fun say(text: String, color: Int = p.fg) { a.print(SB().put(text, color).nl()) }
    private fun ok(t: String) = say(t, p.ok)
    private fun err(t: String) = say(t, p.err)
    private fun dim(t: String) = say(t, p.dim)

    private fun kv(key: String, value: String, width: Int = 9) {
        a.print(SB().put(key.padEnd(width), p.accent).put(value, p.fg).nl())
    }

    private fun meter(key: String, frac: Double, color: Int, text: String) {
        a.print(SB().put(key.padEnd(9), p.accent).bar(frac, 12, color, p.dim).put("  ").put(text, p.fg).nl())
    }

    // ───────────────────────── registry
    private fun reg(
        name: String,
        group: String,
        usage: String,
        desc: String,
        aliases: List<String> = emptyList(),
        arg: ArgKind = ArgKind.NONE,
        options: ((String) -> List<String>)? = null,
        hidden: Boolean = false,
        run: (Args) -> Unit,
    ) {
        val c = Cmd(name, group, usage, desc, aliases, arg, options, hidden, run)
        list.add(c)
        byName[name] = c
        for (al in aliases) byName.getOrPut(al) { c }
    }

    // ───────────────────────── launching
    fun dockItems(): List<Launchable> = store.dock.mapNotNull { id ->
        when {
            id.startsWith("sys:") -> Builtins.byKey(id.removePrefix("sys:"))
            id.startsWith("app:") -> apps.find(id)
            id.startsWith("tui:") -> id.removePrefix("tui:").takeIf { store.tuis.containsKey(it) }?.let { TuiEntry(it) }
            else -> null
        }
    }

    fun launch(l: Launchable) {
        when (l) {
            is AppEntry -> if (!apps.launch(l)) err("could not start ${l.label}")
            is SysEntry -> sys(l.key)
            is TuiEntry -> launchTui(l.name)
        }
    }

    private fun start(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        a.startActivity(i)
        true
    } catch (_: Throwable) {
        false
    }

    private fun startSel(category: String): Boolean =
        start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, category))

    private fun sys(key: String) {
        val done = when (key) {
            "phone" -> start(Intent(Intent.ACTION_DIAL))
            "sms" -> startSel(Intent.CATEGORY_APP_MESSAGING)
            "camera" -> start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "web" -> startSel(Intent.CATEGORY_APP_BROWSER)
            "mail" -> startSel(Intent.CATEGORY_APP_EMAIL)
            "maps" -> startSel(Intent.CATEGORY_APP_MAPS)
            "music" -> startSel(Intent.CATEGORY_APP_MUSIC)
            "gallery" -> startSel(Intent.CATEGORY_APP_GALLERY)
            "cal" -> startSel(Intent.CATEGORY_APP_CALENDAR)
            "contacts" -> startSel(Intent.CATEGORY_APP_CONTACTS)
            "calc" -> startSel(Intent.CATEGORY_APP_CALCULATOR)
            "clock" -> start(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            "settings" -> start(Intent(Settings.ACTION_SETTINGS))
            else -> false
        }
        if (!done) err("no app found for '$key'")
    }

    private fun openQuery(q: String) {
        if (store.tuis.containsKey(q.lowercase())) { launchTui(q.lowercase()); return }
        val s = Builtins.find(q.lowercase())
        if (s != null) { launch(s); return }
        val e = apps.best(q)
        if (e == null) err("no app matches '$q'") else launch(e)
    }

    private fun resolve(q: String): Launchable? =
        store.tuis.keys.firstOrNull { it == q.lowercase() }?.let { TuiEntry(it) } ?: Builtins.find(q.lowercase()) ?: apps.best(q)

    private fun openUrl(url: String) {
        val u = if (url.startsWith("http", ignoreCase = true)) url else "https://$url"
        if (!start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))) err("no app can open that link")
    }

    private fun webSearch(prefix: String, q: String) {
        if (q.isBlank()) { err("nothing to search for"); return }
        openUrl(prefix + Uri.encode(q))
    }

    private fun appLink(sb: SB, e: AppEntry, hid: Set<String>) {
        val col = when {
            e.id in hid -> p.dim
            e.work -> p.accent2
            else -> p.fg
        }
        sb.put(e.display.nb(), col) { launch(e) }
    }

    // ───────────────────────── execution
    fun exec(line: String, depth: Int = 0) {
        if (depth > 6) { err("alias loop"); return }
        for (part in splitCommands(line)) runOne(part.trim(), depth)
    }

    private fun runOne(l: String, depth: Int) {
        if (l.isEmpty()) return
        if (l.startsWith("?")) { webSearch(engines[cfg.engine] ?: engines.getValue("ddg"), l.substring(1).trim()); return }

        val sp = l.indexOfFirst { it.isWhitespace() }
        val name = (if (sp < 0) l else l.substring(0, sp)).lowercase()
        val rest = if (sp < 0) "" else l.substring(sp).trim()

        store.aliases[name]?.let { exp ->
            exec(if (rest.isEmpty()) exp else "$exp $rest", depth + 1)
            return
        }
        if (store.tuis.containsKey(name)) {
            if (name == "music" && rest.lowercase() == "stop") stopMusic() else launchTui(name)
            return
        }
        byName[name]?.let { c ->
            try {
                c.run(Args(rest))
            } catch (t: Throwable) {
                err("${c.name}: ${t.message ?: t.javaClass.simpleName}")
            }
            return
        }
        Calc.tryEval(l)?.let { res -> say("= $res", p.accent); return }
        if (urlRx.matches(l)) { openUrl(l); return }

        val top = complete(l).firstOrNull()
        if (top != null) { top.run(); return }
        notFound(name)
    }

    private fun notFound(name: String) {
        say("nox: command not found: $name", p.err)
        val close = list.filter { !it.hidden }.map { it.name }.filter { Fuzzy.distance(name, it) <= 2 }.take(3)
        if (close.isNotEmpty()) dim("did you mean: ${close.joinToString(", ")}?")
        dim("tip: ? $name   searches the web")
    }

    // ───────────────────────── completion
    private fun appSug(r: Ranked): Sug {
        val e = r.e
        val hl = if (e.display.length == e.label.length) r.m.idx else IntArray(0)
        return Sug(e.display, if (e.work) "work" else "app", if (e.work) p.accent2 else p.fg, hl, e.display, { launch(e) }, { launch(e) })
    }

    fun complete(input: String): List<Sug> {
        val s = input.trimStart()
        if (s.isEmpty()) return emptyList()
        val sp = s.indexOfFirst { it.isWhitespace() }
        if (sp < 0) return completeFirst(s)
        val name = s.substring(0, sp).lowercase()
        val rest = s.substring(sp + 1)
        val cmd = byName[name]
        if (cmd != null) return completeArgs(cmd, rest)
        if (store.aliases.containsKey(name)) return emptyList()
        return apps.search(s.trim(), false, 5).map { appSug(it) }
    }

    private fun completeFirst(q: String): List<Sug> {
        val ql = q.lowercase()
        val ranked = ArrayList<Pair<Int, Sug>>()
        val taken = HashSet<String>()

        for (n in store.aliases.keys) {
            taken.add(n)
            val m = Fuzzy.match(ql, n) ?: continue
            if (m.score < 800) continue
            ranked.add(m.score + 30 to Sug(n, "alias", p.warn, m.idx, "$n ", { a.fill("$n ") }, { exec(n) }))
        }
        for (n in store.tuis.keys) {
            taken.add(n)
            val m = Fuzzy.match(ql, n) ?: continue
            if (m.score < 800) continue
            ranked.add(m.score + 40 to Sug(n, "tui", p.accent, m.idx, n, { launchTui(n) }, { launchTui(n) }))
        }
        for (c in list) {
            for (n in listOf(c.name) + c.aliases) {
                taken.add(n)
                if (c.hidden) continue
                val m = Fuzzy.match(ql, n) ?: continue
                if (m.score < 800) continue
                if (ql.length < 2 && m.score < 1000) continue
                if (n != c.name && m.score < 1000) continue
                ranked.add(m.score - 40 to Sug(n, "cmd", p.accent2, m.idx, "$n ", { a.fill("$n ") }, { exec(n) }))
            }
        }
        for (r in apps.search(q, false, 8)) {
            if (r.e.fold.trim() in taken) continue
            ranked.add(r.rank to appSug(r))
        }
        ranked.sortByDescending { it.first }
        return ranked.take(5).map { it.second }
    }

    private fun completeArgs(cmd: Cmd, restRaw: String): List<Sug> {
        val rest = restRaw.trim()
        return when (cmd.arg) {
            ArgKind.NONE -> emptyList()
            ArgKind.APP -> {
                val found: List<AppEntry> =
                    if (rest.isEmpty()) {
                        val used = store.top(5).mapNotNull { apps.find(it.first) }.filter { it.id !in store.hidden }
                        used.ifEmpty { apps.visible().take(5) }
                    } else apps.search(rest, false, 5).map { it.e }
                found.map { e -> argSug(cmd, e.display, e.work, rest) }
            }
            ArgKind.HIDDEN_APP -> apps.hiddenApps()
                .filter { rest.isEmpty() || Fuzzy.match(rest, it.label) != null }
                .take(5).map { argSug(cmd, it.display, it.work, rest) }
            ArgKind.DOCK -> dockItems()
                .filter { rest.isEmpty() || Fuzzy.match(rest, it.label) != null }
                .take(5).map { argSug(cmd, it.label.lowercase(), false, rest) }
            ArgKind.LIST -> {
                val cands = cmd.options?.invoke(restRaw) ?: return emptyList()
                val rl = restRaw.trimStart().lowercase()
                cands.filter { it.lowercase().startsWith(rl) }.take(5).map { c ->
                    val fill = "${cmd.name} $c"
                    Sug(c, "arg", p.fg, IntArray(rl.length.coerceAtMost(c.length)) { it }, fill, { a.fill(fill) }, { exec(fill) })
                }
            }
        }
    }

    private fun argSug(cmd: Cmd, label: String, work: Boolean, query: String): Sug {
        val fill = "${cmd.name} $label"
        val m = Fuzzy.match(query, label)
        val hl = if (m != null && query.isNotEmpty()) m.idx else IntArray(0)
        val pick: () -> Unit = if (cmd.name == "open") ({ exec(fill) }) else ({ a.fill(fill) })
        return Sug(label, if (work) "work" else "app", if (work) p.accent2 else p.fg, hl, fill, pick, { exec(fill) })
    }

    // ───────────────────────── contact lookup (call / sms)
    private fun target(query: String, onPick: (name: String, number: String) -> Unit) {
        val digits = query.replace(Regex("[\\s\\-().]"), "")
        if (Regex("^[+*#0-9]{2,}$").matches(digits)) { onPick(query.trim(), digits); return }
        a.withPermission(Manifest.permission.READ_CONTACTS) { lookup(query, onPick) }
    }

    private fun lookup(q: String, onPick: (String, String) -> Unit) {
        val rows = LinkedHashMap<String, String>()
        try {
            a.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                "${Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$q%"),
                "${Phone.DISPLAY_NAME} ASC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    if (!rows.containsKey(n)) rows[n] = num
                }
            }
        } catch (t: Throwable) {
            err("contacts: ${t.message}"); return
        }
        val exact = rows.entries.firstOrNull { it.key.equals(q, ignoreCase = true) }
        when {
            exact != null -> onPick(exact.key, exact.value)
            rows.isEmpty() -> err("no contact matches '$q'")
            rows.size == 1 -> rows.entries.first().let { onPick(it.key, it.value) }
            else -> {
                dim("${rows.size} contacts match, tap one:")
                for ((n, num) in rows.entries.take(12)) {
                    a.print(SB().put("  ").put(n.lowercase().nb(), p.accent2) { onPick(n, num) }.put("  $num", p.dim).nl())
                }
            }
        }
    }

    // ───────────────────────── system helpers
    private fun statusBar(settingsPanel: Boolean): Boolean = try {
        val sbm = a.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager")
            .getMethod(if (settingsPanel) "expandSettingsPanel" else "expandNotificationsPanel")
            .invoke(sbm)
        true
    } catch (_: Throwable) {
        false
    }

    /** Pull down the notification shade (or quick settings). Used by `notif`, `qs` and the swipe-down gesture. */
    fun shade(settingsPanel: Boolean) {
        if (statusBar(settingsPanel)) return
        val s = NoxAccess.instance
        val act = if (settingsPanel) AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS else AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
        if (s != null && s.performGlobalAction(act)) return
        err("could not open the shade")
        dim("run: access   (optional service, see README)")
    }

    private fun global(action: Int, what: String) {
        val s = NoxAccess.instance
        if (s == null) {
            err("$what needs the optional accessibility service.")
            dim("run: access   then enable nox (README explains the Samsung step)")
            return
        }
        if (!s.performGlobalAction(action)) err("$what failed")
    }

    private fun mediaKey(code: Int) {
        val am = a.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun torchId(cm: CameraManager): String? = try {
        cm.cameraIdList.firstOrNull { id ->
            val c = cm.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (_: Throwable) {
        null
    }

    // ───────────────────────── termux / tui
    private fun requireTermux(block: () -> Unit) {
        if (!Termux.installed(a)) {
            err("termux is not installed")
            dim("get it from f-droid.org or github.com/termux (not the Play Store)")
            return
        }
        if (!Termux.permitted(a)) {
            a.withPermission(Termux.PERM) { block() }
            return
        }
        block()
    }

    fun launchTui(name: String) {
        val c = store.tuis[name]
        if (c == null) { err("no tui named '$name'"); return }
        requireTermux {
            val e = Termux.launch(a, c)
            if (e != null) err(e)
        }
    }

    /** push the current palette into Termux (silently), but only once tui is actually in use */
    private fun syncTermux() {
        if (store.tuis.isEmpty() || !Termux.installed(a) || !Termux.permitted(a)) return
        val e = Termux.syncTheme(a, cfg.theme)
        if (e != null) err("termux sync: $e")
    }

    private fun stopMusic() {
        requireTermux {
            val e = Termux.stopMusic(a)
            if (e != null) err(e) else ok("music stopped")
        }
    }

    private fun tuiOptions(restRaw: String): List<String> {
        val r = restRaw.trimStart()
        val sp = r.indexOf(' ')
        if (sp < 0) return listOf("setup", "check", "sync", "add", "rm", "run", "list")
        val sub = r.substring(0, sp).lowercase()
        return if (sub == "rm" || sub == "run") store.tuis.keys.map { "$sub $it" } else emptyList()
    }

    private fun parseSeconds(s: String): Int? {
        val t = s.lowercase().replace(" ", "")
        var total = 0
        var pos = 0
        for (m in Regex("(\\d+)([hms]?)").findAll(t)) {
            if (m.range.first != pos) return null
            pos = m.range.last + 1
            val n = m.groupValues[1].toIntOrNull() ?: return null
            total += when (m.groupValues[2]) {
                "h" -> n * 3600
                "s" -> n
                else -> n * 60
            }
        }
        return if (pos == t.length && total > 0) total else null
    }

    init {
        try {
            val cm = a.getSystemService(CameraManager::class.java)
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                }
            }, Handler(Looper.getMainLooper()))
        } catch (_: Throwable) {
        }
        registerLaunch()
        registerPhone()
        registerSystem()
        registerInfo()
        registerTerminal()
    }

    // ═════════════════════════ launch
    private fun registerLaunch() {
        reg("open", "launch", "open <app>", "launch an app", listOf("o", "run"), ArgKind.APP) { x ->
            val q = x.raw.trim()
            if (q.isEmpty()) err("usage: open <app>") else openQuery(q)
        }

        reg("ls", "launch", "ls [-a] [filter]", "list apps (-a: hidden too)", listOf("apps")) { x ->
            val all = x.flag("-a")
            val f = x.noFlags
            val hid = store.hidden
            if (f.isNotBlank()) {
                val found = apps.search(f, all, 500).map { it.e }
                if (found.isEmpty()) { dim("no apps match '$f'"); return@reg }
                val sb = SB()
                for (e in found) appLink(sb, e, hid).also { sb.put("  ", p.fg) }
                a.print(sb.nl())
                dim("${found.size} match")
                return@reg
            }
            val items = if (all) apps.all else apps.visible()
            if (items.isEmpty()) { dim("no apps indexed yet, try: reload"); return@reg }
            var cur = '\u0000'
            var sb = SB()
            for (e in items) {
                val first = e.label.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar() ?: '#'
                val ch = if (first.isLetter()) first else '#'
                if (ch != cur) {
                    if (sb.isNotEmpty()) a.print(sb.nl())
                    sb = SB().put("$ch  ", p.dim)
                    cur = ch
                }
                appLink(sb, e, hid)
                sb.put("  ", p.fg)
            }
            if (sb.isNotEmpty()) a.print(sb.nl())
            dim("${items.size} apps" + if (!all && hid.isNotEmpty()) " · ${hid.size} hidden (ls -a)" else "")
        }

        reg("dock", "launch", "dock [reset]", "show or reset the pinned row", arg = ArgKind.LIST, options = { listOf("reset") }) { x ->
            if (x.first == "reset") {
                store.resetDock(); a.renderHeader(); ok("dock reset")
                return@reg
            }
            val items = dockItems()
            if (items.isEmpty()) dim("dock is empty. try: pin <app>")
            for (i in items) kv("[${i.label.lowercase()}]", i.id, 14)
        }

        reg("pin", "launch", "pin <app>", "add to the dock", arg = ArgKind.APP) { x ->
            val q = x.raw.trim()
            val t = resolve(q)
            if (t == null) { err("no app matches '$q'"); return@reg }
            val d = store.dock
            if (t.id in d) { dim("already pinned"); return@reg }
            store.dock = d + t.id
            a.renderHeader()
            ok("pinned ${t.label.lowercase()}")
        }

        reg("unpin", "launch", "unpin <app>", "remove from the dock", arg = ArgKind.DOCK) { x ->
            val q = x.raw.trim()
            val t = dockItems().mapNotNull { l -> Fuzzy.match(q, l.label)?.let { l to it.score } }.maxByOrNull { it.second }?.first
            if (t == null) { err("not in the dock: '$q'"); return@reg }
            store.dock = store.dock.filter { it != t.id }
            a.renderHeader()
            ok("unpinned ${t.label.lowercase()}")
        }

        reg("hide", "launch", "hide <app>", "hide from lists & suggestions", arg = ArgKind.APP) { x ->
            val e = apps.best(x.raw.trim())
            if (e == null) { err("no app matches '${x.raw.trim()}'"); return@reg }
            store.hide(e.id)
            a.renderHeader()
            ok("hidden: ${e.display}  (type its exact name to still launch it)")
        }

        reg("unhide", "launch", "unhide <app>", "bring a hidden app back", arg = ArgKind.HIDDEN_APP) { x ->
            val q = x.raw.trim()
            val e = apps.search(q, true).firstOrNull { it.e.id in store.hidden }?.e
            if (e == null) { err("no hidden app matches '$q'"); return@reg }
            store.unhide(e.id)
            a.renderHeader()
            ok("visible again: ${e.display}")
        }

        reg("hidden", "launch", "hidden", "list hidden apps") {
            val h = apps.hiddenApps()
            if (h.isEmpty()) dim("nothing hidden") else for (e in h) say("  ${e.display}", p.dim)
        }

        reg("info", "launch", "info <app>", "open the app's system info page", arg = ArgKind.APP) { x ->
            val e = apps.best(x.raw.trim())
            if (e == null) { err("no app matches '${x.raw.trim()}'"); return@reg }
            if (!start(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))) err("could not open")
        }

        reg("uninstall", "launch", "uninstall <app>", "remove an app", arg = ArgKind.APP) { x ->
            val e = apps.best(x.raw.trim())
            if (e == null) { err("no app matches '${x.raw.trim()}'"); return@reg }
            if (!start(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}")))) err("could not start uninstall")
        }

        reg("pkg", "launch", "pkg <app>", "print package name", arg = ArgKind.APP) { x ->
            val e = apps.best(x.raw.trim(), true)
            if (e == null) { err("no app matches '${x.raw.trim()}'"); return@reg }
            kv("name", e.label)
            kv("package", e.pkg)
            kv("activity", e.cls)
            kv("profile", if (e.work) "work" else "personal")
            kv("launches", store.uses(e.id).toString())
        }

        reg("top", "launch", "top", "your most launched apps") {
            val t = store.top(10)
            if (t.isEmpty()) { dim("nothing launched yet"); return@reg }
            val max = t.first().second.toDouble()
            for ((id, n) in t) {
                val label = apps.find(id)?.display ?: Builtins.byKey(id.removePrefix("sys:"))?.label ?: id
                a.print(SB().put(label.take(16).padEnd(17), p.fg).bar(n / max, 10, p.accent, p.dim).put("  $n", p.dim).nl())
            }
        }

        reg("reload", "launch", "reload", "re-scan installed apps") {
            apps.reload {
                a.renderHeader()
                a.refreshSuggestions()
                ok("indexed ${apps.all.size} apps")
            }
        }

        reg("alias", "launch", "alias [name=command]", "define a shortcut or macro") { x ->
            val raw = x.raw.trim()
            if (raw.isEmpty()) {
                val m = store.aliases
                if (m.isEmpty()) dim("no aliases. example: alias gm=gmail   or   alias night=\"vol 0; flash off\"")
                for ((k, v) in m) a.print(SB().put(k.padEnd(10), p.warn).put(v, p.fg).nl())
                return@reg
            }
            val eq = raw.indexOf('=')
            if (eq < 1) { err("usage: alias name=command"); return@reg }
            val name = raw.substring(0, eq).trim().lowercase()
            val value = unquote(raw.substring(eq + 1).trim())
            if (!Regex("^[a-z0-9_.-]+$").matches(name)) { err("alias names: letters, digits, - _ ."); return@reg }
            if (value.isEmpty()) { err("alias needs a command"); return@reg }
            store.setAlias(name, value)
            ok("alias $name = $value")
        }

        reg("unalias", "launch", "unalias <name>", "delete an alias", arg = ArgKind.LIST, options = { store.aliases.keys.toList() }) { x ->
            val n = x.first.lowercase()
            if (store.removeAlias(n)) ok("removed $n") else err("no alias '$n'")
        }
    }

    // ═════════════════════════ phone, apps, search
    private fun engineUrl(): String = engines[cfg.engine] ?: engines.getValue("ddg")

    private fun registerPhone() {
        reg("phone", "phone", "phone [name|number]", "dialer, or call someone", listOf("call", "dial")) { x ->
            val q = x.raw.trim()
            if (q.isEmpty()) { sys("phone"); return@reg }
            target(q) { name, number ->
                if (start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))) dim("dialing $name") else err("no dialer found")
            }
        }

        reg("sms", "phone", "sms [who] [text]", "messages, or compose one", listOf("msg")) { x ->
            if (x.list.isEmpty()) { sys("sms"); return@reg }
            val body = x.list.drop(1).joinToString(" ")
            target(x.list[0]) { name, number ->
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
                if (body.isNotEmpty()) i.putExtra("sms_body", body)
                if (start(i)) dim("to $name") else err("no messaging app found")
            }
        }

        reg("camera", "phone", "camera", "open the camera", listOf("cam")) { sys("camera") }

        reg("web", "phone", "web [url|query]", "browser, link, or search", listOf("browser", "www")) { x ->
            val q = x.raw.trim()
            when {
                q.isEmpty() -> sys("web")
                urlRx.matches(q) -> openUrl(q)
                else -> webSearch(engineUrl(), q)
            }
        }

        reg("mail", "phone", "mail", "open email") { sys("mail") }

        reg("maps", "phone", "maps [place]", "open maps, or search a place") { x ->
            val q = x.raw.trim()
            if (q.isEmpty()) sys("maps")
            else if (!start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))) {
                openUrl("https://www.google.com/maps/search/" + Uri.encode(q))
            }
        }

        reg("music", "phone", "music", "open the music app") { sys("music") }
        reg("gallery", "phone", "gallery", "open photos") { sys("gallery") }
        reg("cal", "phone", "cal", "open the calendar") { sys("cal") }
        reg("contacts", "phone", "contacts", "open contacts") { sys("contacts") }
        reg("clock", "phone", "clock", "alarms & clock") { sys("clock") }

        reg("calc", "phone", "calc [expression]", "calculator, or do the math here") { x ->
            val q = x.raw.trim()
            if (q.isEmpty()) { sys("calc"); return@reg }
            val r = Calc.tryEval(q)
            if (r != null) say("= $r", p.accent) else err("cannot evaluate '$q'")
        }

        reg("settings", "phone", "settings [section]", "android settings", arg = ArgKind.LIST, options = { sections.keys.toList() }) { x ->
            val k = x.first.lowercase()
            if (k.isEmpty()) { sys("settings"); return@reg }
            val action = sections[k]
            if (action == null) {
                err("unknown section '$k'")
                dim("sections: ${sections.keys.joinToString(" ")}")
                return@reg
            }
            if (!start(Intent(action))) err("this phone has no '$k' page")
        }

        reg("s", "search", "s <query>", "web search (default engine)") { x -> webSearch(engineUrl(), x.raw.trim()) }
        reg("g", "search", "g <query>", "search google") { x -> webSearch(engines.getValue("google"), x.raw.trim()) }
        reg("ddg", "search", "ddg <query>", "search duckduckgo") { x -> webSearch(engines.getValue("ddg"), x.raw.trim()) }
        reg("yt", "search", "yt <query>", "search youtube") { x ->
            webSearch("https://www.youtube.com/results?search_query=", x.raw.trim())
        }
        reg("wiki", "search", "wiki <query>", "search wikipedia") { x ->
            webSearch("https://en.wikipedia.org/wiki/Special:Search?search=", x.raw.trim())
        }
    }

    // ═════════════════════════ system controls
    private fun registerSystem() {
        reg("wifi", "system", "wifi", "internet panel") {
            if (!start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) && !start(Intent(Settings.ACTION_WIFI_SETTINGS))) err("could not open")
        }
        reg("bt", "system", "bt", "bluetooth settings", listOf("bluetooth")) {
            if (!start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) err("could not open")
        }

        reg("vol", "system", "vol [up|down|mute|max|0-100]", "media volume", arg = ArgKind.LIST, options = { listOf("up", "down", "mute", "max", "panel") }) { x ->
            val am = a.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val arg = x.first.lowercase()
            when {
                arg.isEmpty() -> {
                    val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    meter("volume", cur.toDouble() / max, p.accent, "${cur * 100 / max}%")
                }
                arg == "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                arg == "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                arg == "mute" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                arg == "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                arg == "panel" -> start(Intent(Settings.Panel.ACTION_VOLUME))
                else -> {
                    val n = arg.trimEnd('%').toIntOrNull()
                    if (n == null || n !in 0..100) err("usage: vol up|down|mute|max|0-100")
                    else am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(n / 100f * max), AudioManager.FLAG_SHOW_UI)
                }
            }
        }

        reg("ring", "system", "ring <normal|vibrate>", "ringer mode", arg = ArgKind.LIST, options = { listOf("normal", "vibrate") }) { x ->
            val am = a.getSystemService(AudioManager::class.java)
            val mode = when (x.first.lowercase()) {
                "normal" -> AudioManager.RINGER_MODE_NORMAL
                "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                else -> { err("usage: ring normal|vibrate"); return@reg }
            }
            try {
                am.ringerMode = mode
                ok("ringer: ${x.first.lowercase()}")
            } catch (t: Throwable) {
                err("ring: ${t.message}")
            }
        }

        reg("flash", "system", "flash [on|off]", "flashlight", listOf("torch"), ArgKind.LIST, { listOf("on", "off") }) { x ->
            val cm = a.getSystemService(CameraManager::class.java)
            val id = torchId(cm)
            if (id == null) { err("no flashlight found"); return@reg }
            val want = when (x.first.lowercase()) {
                "on", "1" -> true
                "off", "0" -> false
                else -> !torchOn
            }
            try {
                cm.setTorchMode(id, want)
                torchOn = want
                ok("flashlight " + if (want) "on" else "off")
            } catch (t: Throwable) {
                err("flash: ${t.message}")
            }
        }

        reg("media", "system", "media <play|pause|next|prev>", "control playback", arg = ArgKind.LIST, options = { listOf("play", "pause", "next", "prev", "stop") }) { x ->
            when (x.first.lowercase()) {
                "", "toggle" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                "play" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
                "pause" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
                "next" -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
                "prev", "previous" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "stop" -> mediaKey(KeyEvent.KEYCODE_MEDIA_STOP)
                else -> err("usage: media play|pause|next|prev|stop")
            }
        }
        reg("pp", "system", "pp", "play / pause") { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        reg("next", "system", "next", "next track") { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) }
        reg("prev", "system", "prev", "previous track") { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }

        reg("alarm", "system", "alarm <7:30> [label]", "set an alarm (or list them)") { x ->
            if (x.raw.isBlank()) { start(Intent(AlarmClock.ACTION_SHOW_ALARMS)); return@reg }
            val m = alarmRx.matchEntire(x.list[0])
            if (m == null) { err("usage: alarm 7:30 [label]   or   alarm 6pm"); return@reg }
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3].lowercase()
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h > 23 || min > 59) { err("that is not a time"); return@reg }
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min)
                .putExtra(AlarmClock.EXTRA_MESSAGE, x.list.drop(1).joinToString(" "))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (start(i)) ok(String.format(Locale.ENGLISH, "alarm set for %02d:%02d", h, min)) else err("no clock app found")
        }

        reg("timer", "system", "timer <5m|1h30m|90s>", "start a countdown") { x ->
            val s = parseSeconds(x.raw)
            if (s == null) { err("usage: timer 5m   (also 90s, 1h30m, or just 10 = minutes)"); return@reg }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, s)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (start(i)) ok("timer: ${Sys.duration(s.toLong()).ifEmpty { "0m" }}${if (s < 60) " (${s}s)" else ""}") else err("no clock app found")
        }

        reg("tui", "system", "tui [setup|check|sync|add|rm|run]", "terminal apps in termux", arg = ArgKind.LIST, options = { tuiOptions(it) }) { x ->
            val sub = x.first.lowercase()
            val rest = x.raw.trim().substringAfter(' ', "").trim()
            when (sub) {
                "", "list" -> {
                    val m = store.tuis
                    if (m.isEmpty()) {
                        dim("no terminal apps yet.")
                        dim("1) tui check    2) tui setup    then type: music")
                        return@reg
                    }
                    for ((n, c) in m) a.print(SB().put(n.padEnd(10), p.accent) { launchTui(n) }.put(c, p.dim).nl())
                }
                "check" -> {
                    val inst = Termux.installed(a)
                    val perm = Termux.permitted(a)
                    kv("termux", if (inst) "installed" else "missing (f-droid.org or github.com/termux)", 11)
                    kv("permission", if (perm) "granted" else "not yet (nox asks on first use)", 11)
                    say("one-time step, run this inside termux:", p.fg)
                    say("  ${Termux.ALLOW_CMD}", p.accent2)
                    try {
                        a.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("nox", Termux.ALLOW_CMD))
                        dim("copied to your clipboard. paste it in termux, then close termux completely.")
                    } catch (_: Throwable) {
                    }
                }
                "setup" -> requireTermux {
                    val e = Termux.setup(a, cfg.theme)
                    if (e != null) {
                        err(e)
                    } else {
                        store.setTui("music", "~/.nox/bin/music")
                        ok("setup is running in termux. follow it there.")
                        dim("when it finishes you land back here. then type: music")
                    }
                }
                "sync" -> requireTermux {
                    val e = Termux.syncTheme(a, cfg.theme)
                    if (e != null) err(e) else ok("termux now uses the ${cfg.theme} theme")
                }
                "add" -> {
                    val name = rest.substringBefore(' ').lowercase()
                    val cmd = rest.substringAfter(' ', "").trim()
                    if (!Regex("^[a-z0-9_.-]+$").matches(name) || cmd.isEmpty()) {
                        err("usage: tui add <name> <command>     e.g. tui add files nnn")
                        return@reg
                    }
                    store.setTui(name, cmd)
                    ok("added: $name  ->  $cmd")
                    if (byName.containsKey(name)) dim("note: this overrides the built-in '$name' command")
                }
                "rm" -> if (store.removeTui(rest.lowercase())) ok("removed $rest") else err("no tui named '$rest'")
                "run" -> launchTui(rest.lowercase())
                else -> err("usage: tui [setup|check|sync|add <name> <cmd>|rm <name>|run <name>]")
            }
        }

        reg("stop", "system", "stop", "stop the termux music player") { stopMusic() }

        reg("lock", "system", "lock", "screen off (needs service)") { global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "lock") }
        reg("notif", "system", "notif", "pull down notifications") { shade(false) }
        reg("qs", "system", "qs", "quick settings") { shade(true) }
        reg("recents", "system", "recents", "app switcher (needs service)") { global(AccessibilityService.GLOBAL_ACTION_RECENTS, "recents") }

        reg("access", "system", "access", "enable the optional service") {
            say("the optional service powers: lock, recents, and the shade fallback", p.fg)
            dim("1. open 'installed apps' and switch nox on")
            dim("2. if it is greyed out: App info > nox > ⋮ > Allow restricted settings")
            dim("note: some banking apps refuse to run while ANY accessibility service is on")
            if (!start(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))) err("could not open accessibility settings")
        }
    }

    // ═════════════════════════ info
    private fun registerInfo() {
        reg("fetch", "info", "fetch", "system summary", listOf("neofetch")) {
            a.print(Fetch.header(a, a.cols, withExtras = false).nl())
        }

        reg("date", "info", "date", "date and time", listOf("time")) {
            say(SimpleDateFormat("EEEE, dd MMMM yyyy  HH:mm:ss", Locale.ENGLISH).format(Date()), p.fg)
        }

        reg("bat", "info", "bat", "battery details", listOf("battery")) {
            val b = Sys.battery(a)
            val col = when {
                b.pct >= 50 -> p.ok
                b.pct >= 20 -> p.warn
                else -> p.err
            }
            meter("level", b.pct / 100.0, col, "${b.pct}%")
            kv("status", when {
                b.charging -> "charging"
                b.full -> "full"
                b.onPower -> "plugged, not charging"
                else -> "discharging"
            })
            if (b.onPower) kv("source", Sys.plugText(b.plugged))
            val eta = Sys.chargeEtaMs(a)
            if (b.charging && eta > 0) kv("to full", Sys.duration(eta / 1000))
            kv("temp", String.format(Locale.ENGLISH, "%.1f°C", b.tempC))
            kv("voltage", String.format(Locale.ENGLISH, "%.2fV", b.mv / 1000.0))
            kv("health", Sys.healthText(b.health))
        }

        reg("mem", "info", "mem", "memory usage", listOf("free")) {
            val (u, t) = Sys.memory(a)
            val f = if (t > 0) u.toDouble() / t else 0.0
            val col = if (f < 0.7) p.ok else if (f < 0.88) p.warn else p.err
            meter("memory", f, col, "${Sys.gib(u)} / ${Sys.gib(t)}")
            kv("free", Sys.gib(t - u))
        }

        reg("df", "info", "df", "storage usage") {
            val (u, t) = Sys.storage(a)
            val f = if (t > 0) u.toDouble() / t else 0.0
            val col = if (f < 0.7) p.ok else if (f < 0.88) p.warn else p.err
            meter("storage", f, col, "${Sys.gb(u)} / ${Sys.gb(t)}")
            kv("free", Sys.gb(t - u))
        }

        reg("uptime", "info", "uptime", "time since boot") { say("up ${Sys.uptime()}", p.fg) }
        reg("net", "info", "net", "connection type") { say(Sys.net(a), p.fg) }

        reg("uname", "info", "uname", "kernel & device") {
            say("Linux ${Sys.kernelFull()} ${Build.SUPPORTED_ABIS.firstOrNull() ?: ""} Android ${Build.VERSION.RELEASE}", p.fg)
        }

        reg("ver", "info", "ver", "nox version", listOf("version")) {
            say("nox ${Sys.version(a)}", p.accent)
            dim("font: JetBrains Mono (SIL OFL)  ·  no network permission")
        }
    }

    // ═════════════════════════ terminal
    private fun setOptions(restRaw: String): List<String> {
        val r = restRaw.trimStart()
        val sp = r.indexOf(' ')
        if (sp < 0) return opts.map { it.key }
        val key = r.substring(0, sp).lowercase()
        return opts.firstOrNull { it.key == key }?.values?.map { "$key $it" } ?: emptyList()
    }

    private fun showTodos() {
        val l = store.todos
        if (l.isEmpty()) { dim("nothing to do. add one: todo buy milk"); return }
        for ((i, t) in l.withIndex()) a.print(SB().put("${(i + 1).toString().padStart(3)}  ", p.dim).put(t, p.fg).nl())
    }

    private fun removeTodo(n: Int?) {
        val l = store.todos
        if (n == null || n < 1 || n > l.size) { err("usage: todo rm <1-${l.size}>"); return }
        store.todos = l.filterIndexed { i, _ -> i != n - 1 }
        a.renderHeader()
        ok("done: ${l[n - 1]}")
    }

    fun welcome() {
        a.print(
            SB().put("nox ${Sys.version(a)}", p.accent, bold = true).put("  ·  a launcher that is a terminal", p.dim).nl()
                .put("type part of an app name, press enter.", p.fg).nl()
                .put("tap ", p.dim).put("help", p.accent2) { a.fill("help") }.put(" for commands  ·  ", p.dim)
                .put("settings home", p.accent2) { exec("settings home") }.put(" to make nox your home app", p.dim).nl(),
        )
    }

    private fun registerTerminal() {
        reg("help", "terminal", "help [command]", "this list", listOf("h", "man"), ArgKind.LIST, { list.filter { !it.hidden }.map { it.name } }) { x ->
            val n = x.first.lowercase()
            if (n.isNotEmpty()) {
                val c = byName[n]
                if (c == null) { err("no such command: $n"); return@reg }
                say(c.usage, p.accent2)
                say("  ${c.desc}", p.fg)
                if (c.aliases.isNotEmpty()) dim("  aliases: ${c.aliases.joinToString(", ")}")
                return@reg
            }
            val titles = linkedMapOf(
                "launch" to "apps", "phone" to "phone", "search" to "search",
                "system" to "system", "info" to "info", "terminal" to "terminal",
            )
            for ((g, title) in titles) {
                say(title, p.accent)
                for (c in list) {
                    if (c.group != g || c.hidden) continue
                    a.print(SB().put("  ").put(c.name.padEnd(10), p.accent2) { a.fill("${c.name} ") }.put(c.desc, p.dim).nl())
                }
            }
            dim("anything else you type is matched against your apps. 2+2 does math. ? foo searches the web.")
            dim("a; b runs two commands. tap a name above to fill it in.")
        }

        reg("clear", "terminal", "clear", "clear the screen", listOf("cls")) { a.clearOutput() }

        reg("history", "terminal", "history", "recent commands") {
            val all = store.history
            val h = all.takeLast(30)
            if (h.isEmpty()) { dim("empty"); return@reg }
            val base = all.size - h.size
            for ((i, c) in h.withIndex()) {
                a.print(SB().put("${(base + i + 1).toString().padStart(4)}  ", p.dim).put(c, p.fg) { a.fill(c) }.nl())
            }
            dim("!! repeats the last one, !<n> repeats entry n")
        }

        reg("echo", "terminal", "echo <text>", "print text") { x -> say(x.raw, p.fg) }

        reg("theme", "terminal", "theme [name]", "list or switch themes", arg = ArgKind.LIST, options = { Themes.all.map { it.name } }) { x ->
            val n = x.first.lowercase()
            if (n.isEmpty()) {
                for (t in Themes.all) {
                    val sb = SB()
                    for (c in listOf(t.accent, t.accent2, t.ok, t.warn, t.err)) sb.put("██", c)
                    sb.put("  ").put(t.name, t.fg) { exec("theme ${t.name}") }
                    if (t.name == cfg.theme) sb.put("  ← current", p.dim)
                    a.print(sb.nl())
                }
                return@reg
            }
            val t = Themes.all.firstOrNull { it.name == n }
            if (t == null) { err("no theme '$n'"); return@reg }
            cfg.theme = t.name
            a.applyConfig()
            ok("theme: ${t.name}")
            syncTermux()
        }

        reg("set", "terminal", "set [key] [value]", "show or change settings", arg = ArgKind.LIST, options = { setOptions(it) }) { x ->
            val raw = x.raw.trim()
            if (raw.isEmpty()) {
                for (o in opts) {
                    val v = o.get().let { if (it.length > 14) it.take(13) + "…" else it }
                    a.print(SB().put(o.key.padEnd(11), p.accent) { a.fill("set ${o.key} ") }.put(v.padEnd(15), p.fg).put(o.desc, p.dim).nl())
                }
                dim("example: set theme matrix   ·   set size 14   ·   set kbd auto")
                return@reg
            }
            val sp = raw.indexOfFirst { it.isWhitespace() }
            val key = (if (sp < 0) raw else raw.substring(0, sp)).lowercase()
            val value = unquote(if (sp < 0) "" else raw.substring(sp).trim())
            val o = opts.firstOrNull { it.key == key }
            if (o == null) { err("unknown setting '$key'  (try: set)"); return@reg }
            if (sp < 0) {
                kv(o.key, o.get(), 11)
                dim("  ${o.desc}" + (o.values?.let { "  [${it.joinToString(" ")}]" } ?: ""))
                return@reg
            }
            val e = o.set(value)
            if (e != null) err("${o.key}: $e") else {
                a.applyConfig()
                ok("${o.key} = ${o.get()}")
                if (o.key == "theme" || o.key == "bg") syncTermux()
            }
        }

        reg("todo", "terminal", "todo [text]", "todo list (rm <n> | clear)", listOf("todos")) { x ->
            val raw = x.raw.trim()
            val word = raw.substringBefore(' ').lowercase()
            when {
                raw.isEmpty() -> showTodos()
                raw.lowercase() == "clear" -> { store.todos = emptyList(); a.renderHeader(); ok("cleared") }
                (word == "rm" || word == "done" || word == "del") && raw.contains(' ') -> removeTodo(raw.substringAfter(' ').trim().toIntOrNull())
                else -> {
                    val n = store.todos.size
                    store.todos = store.todos + raw
                    a.renderHeader()
                    ok("added #${n + 1}")
                }
            }
        }
        reg("done", "terminal", "done <n>", "finish a todo") { x -> removeTodo(x.first.toIntOrNull()) }

        reg("whoami", "terminal", "whoami", "who you are") { say(cfg.user, p.fg) }

        reg("sudo", "terminal", "sudo", "", hidden = true) { say("${cfg.user} is not in the sudoers file. This incident will be reported.", p.err) }
        reg("exit", "terminal", "exit", "", listOf("quit", "logout"), hidden = true) { say("there is nowhere to go. this is home.", p.dim) }
    }
}
