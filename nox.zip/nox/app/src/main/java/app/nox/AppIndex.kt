package app.nox

import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherApps
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import java.util.concurrent.Executors

/** Anything that can sit in the dock or be launched by name. */
interface Launchable {
    val id: String
    val label: String
}

/** An installed app (any profile: personal or work). */
class AppEntry(
    override val label: String,
    val pkg: String,
    val cls: String,
    val user: UserHandle,
    val work: Boolean,
) : Launchable {
    override val id: String = "app:$pkg/$cls" + if (work) "@w" else ""
    val fold: String = Fuzzy.fold(label)
    val display: String get() = label.lowercase()
}

/** Built-in shortcuts that resolve to whatever default app the phone has (dialer, camera, browser...). */
class SysEntry(val key: String, override val label: String) : Launchable {
    override val id: String = "sys:$key"
}

object Builtins {
    val all: List<SysEntry> = listOf(
        SysEntry("phone", "phone"),
        SysEntry("sms", "messages"),
        SysEntry("camera", "camera"),
        SysEntry("web", "browser"),
        SysEntry("mail", "mail"),
        SysEntry("maps", "maps"),
        SysEntry("music", "music"),
        SysEntry("gallery", "gallery"),
        SysEntry("cal", "calendar"),
        SysEntry("contacts", "contacts"),
        SysEntry("clock", "clock"),
        SysEntry("calc", "calc"),
        SysEntry("settings", "settings"),
    )

    fun byKey(k: String): SysEntry? = all.firstOrNull { it.key == k }
    fun find(q: String): SysEntry? = all.firstOrNull { it.key == q || it.label == q }
}

class Ranked(val e: AppEntry, val m: Match, val rank: Int)

class AppIndex(private val ctx: Context, private val store: Store) {
    private val la: LauncherApps = ctx.getSystemService(LauncherApps::class.java)
    private val um: UserManager = ctx.getSystemService(UserManager::class.java)
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var all: List<AppEntry> = emptyList()
        private set

    /** Rebuild the app list off the main thread, then call [done] on the main thread. */
    fun reload(done: (() -> Unit)? = null) {
        io.execute {
            val list = ArrayList<AppEntry>()
            try {
                val me = Process.myUserHandle()
                for (u in um.userProfiles) {
                    val work = u != me
                    for (info in la.getActivityList(null, u)) {
                        val pkg = info.applicationInfo.packageName
                        if (pkg == ctx.packageName) continue
                        list.add(AppEntry(info.label.toString(), pkg, info.componentName.className, u, work))
                    }
                }
            } catch (_: Throwable) {
                // keep whatever we got
            }
            list.sortBy { it.label.lowercase() }
            all = list
            main.post { done?.invoke() }
        }
    }

    fun visible(): List<AppEntry> {
        val h = store.hidden
        return all.filter { it.id !in h }
    }

    fun hiddenApps(): List<AppEntry> {
        val h = store.hidden
        return all.filter { it.id in h }
    }

    fun find(id: String): AppEntry? = all.firstOrNull { it.id == id }

    /** Ranked search. Hidden apps only show up on an EXACT name match (so they stay out of the way but stay reachable). */
    fun search(q: String, includeHidden: Boolean = false, limit: Int = 50): List<Ranked> {
        val hid = store.hidden
        val out = ArrayList<Ranked>()
        for (e in all) {
            val m = Fuzzy.match(q, e.label) ?: continue
            if (!includeHidden && e.id in hid && m.score < 1000) continue
            out.add(Ranked(e, m, m.score + minOf(49, store.uses(e.id) * 3)))
        }
        out.sortWith(
            compareByDescending<Ranked> { it.rank }
                .thenBy { it.e.label.length }
                .thenBy { it.e.label.lowercase() },
        )
        return if (out.size > limit) out.subList(0, limit) else out
    }

    fun best(q: String, includeHidden: Boolean = false): AppEntry? = search(q, includeHidden, 1).firstOrNull()?.e

    fun launch(e: AppEntry): Boolean = try {
        la.startMainActivity(ComponentName(e.pkg, e.cls), e.user, null, null)
        store.bump(e.id)
        true
    } catch (_: Throwable) {
        false
    }
}
