package app.nox

import android.content.Context
import android.graphics.Color
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** All user-facing settings. Every property is persisted instantly. Change them with the `set` command. */
class Config(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nox_cfg", Context.MODE_PRIVATE)

    private fun str(k: String, d: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(k, value).apply()
        }
    }

    private fun int(k: String, d: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(k, value).apply()
        }
    }

    private fun bool(k: String, d: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(k, value).apply()
        }
    }

    var theme by str("theme", "void")
    var bg by int("bg", Color.BLACK)
    var size by int("size", 13)
    var clock by str("clock", "big")          // big | small | off
    var hour by str("hour", "auto")           // auto | 12 | 24
    var header by bool("header", true)        // the whole fetch panel
    var dock by bool("dock", true)            // the row of [pinned] apps
    var fields by str("fields", "os,device,uptime,net,battery,memory,storage")
    var todos by int("todos", 0)              // how many todos to show on home
    var kbd by str("kbd", "manual")           // manual | auto  (keyboard on every home press)
    var autolaunch by bool("autolaunch", false)
    var strict by bool("strict", false)       // hard "no autocorrect" keyboard mode
    var cursor by str("cursor", "block")      // block | bar
    var wallpaper by bool("wallpaper", false)
    var dim by int("dim", 70)                 // wallpaper darkening, 0..100
    var engine by str("engine", "ddg")
    var prompt by str("prompt", "❯")
    var user by str("user", "user")
    var host by str("host", "nox")
    var welcomed by bool("welcomed", false)

    val pal: Palette get() = Themes.get(theme)
}
