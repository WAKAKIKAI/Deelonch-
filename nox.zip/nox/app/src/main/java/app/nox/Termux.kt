package app.nox

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Bridge to Termux through its official RUN_COMMAND intent.
 * One-time requirements (nox walks you through them with `tui check`):
 *   1. Termux from F-Droid / GitHub (the Play Store build is abandoned)
 *   2. `allow-external-apps=true` in ~/.termux/termux.properties
 *   3. nox granted the "Run commands in Termux" permission
 */
object Termux {
    const val PKG = "com.termux"
    const val PERM = "com.termux.permission.RUN_COMMAND"
    const val ALLOW_CMD = "mkdir -p ~/.termux && echo 'allow-external-apps=true' >> ~/.termux/termux.properties"

    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME = "/data/data/com.termux/files/home"

    /** after any TUI exits, jump back to the home screen (which is nox) */
    private const val BACK_HOME = "am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1"

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (_: Throwable) {
        false
    }

    fun permitted(ctx: Context): Boolean = ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    private fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

    /** the bridge script with your current palette baked in */
    private fun script(ctx: Context, p: Palette, bg: Int): String {
        val raw = ctx.assets.open("termux/nox-termux.sh").bufferedReader().use { it.readText() }
        return raw
            .replace("@BG@", hex(bg)).replace("@FG@", hex(p.fg)).replace("@DIM@", hex(p.dim))
            .replace("@ACCENT@", hex(p.accent)).replace("@ACCENT2@", hex(p.accent2))
            .replace("@OK@", hex(p.ok)).replace("@WARN@", hex(p.warn)).replace("@ERR@", hex(p.err))
    }

    /** returns null on success, otherwise a human readable error */
    private fun run(ctx: Context, args: Array<String>, foreground: Boolean, label: String): String? {
        val i = Intent("com.termux.RUN_COMMAND")
            .setClassName(PKG, "com.termux.app.RunCommandService")
            .putExtra("com.termux.RUN_COMMAND_PATH", BASH)
            .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args)
            .putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            .putExtra("com.termux.RUN_COMMAND_BACKGROUND", !foreground)
            .putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
            .putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", label)
        return try {
            ctx.startForegroundService(i)
            null
        } catch (e: SecurityException) {
            "termux refused: grant the permission and set allow-external-apps (run: tui check)"
        } catch (e: Throwable) {
            e.message ?: e.javaClass.simpleName
        }
    }

    /** mode = "setup" (visible, installs everything) or "theme" (silent, only rewrites colours) */
    fun runScript(ctx: Context, mode: String, p: Palette, bg: Int, foreground: Boolean): String? =
        run(ctx, arrayOf("-c", script(ctx, p, bg), "nox", mode), foreground, "nox $mode")

    /** open a TUI in a Termux session, and come back to nox when it exits */
    fun launch(ctx: Context, command: String): String? =
        run(ctx, arrayOf("-c", "$command; $BACK_HOME"), true, command)
}
