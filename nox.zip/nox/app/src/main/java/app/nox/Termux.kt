package app.nox

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Bridge to Termux through its official RUN_COMMAND intent.
 * One-time requirements (nox walks you through them with `tui check`):
 *   1. Termux from F-Droid / GitHub (the Play Store build is abandoned)
 *   2. `allow-external-apps=true` in ~/.termux/termux.properties
 *   3. nox granted the "Run commands in Termux" permission
 */
object Termux {
    const val PKG = "com.termux"
    const val PERM = "com.termux.permission.RUN_COMMAND"
    const val ALLOW_CMD = "mkdir -p ~/.termux && echo 'allow-external-apps=true' >> ~/.termux/termux.properties"

    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME = "/data/data/com.termux/files/home"

    /** after any TUI exits, jump back to the home screen (which is nox) */
    private const val BACK_HOME = "am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1"

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (_: Throwable) {
        false
    }

    fun permitted(ctx: Context): Boolean = ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    /** returns null on success, otherwise a human readable error */
    private fun run(ctx: Context, args: Array<String>, foreground: Boolean, label: String): String? {
        val i = Intent("com.termux.RUN_COMMAND")
            .setClassName(PKG, "com.termux.app.RunCommandService")
            .putExtra("com.termux.RUN_COMMAND_PATH", BASH)
            .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args)
            .putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            .putExtra("com.termux.RUN_COMMAND_BACKGROUND", !foreground)
            .putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
            .putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", label)
        return try {
            ctx.startForegroundService(i)
            null
        } catch (e: SecurityException) {
            "termux refused: grant the permission and set allow-external-apps (run: tui check)"
        } catch (e: Throwable) {
            e.message ?: e.javaClass.simpleName
        }
    }

    /** install the music stack: drops the bundled script into ~/.nox/bin, then runs `install <theme>` visibly */
    fun setup(ctx: Context, theme: String): String? {
        val raw = ctx.assets.open("termux/nox-music.sh").bufferedReader().use { it.readText() }
        val cmd = "mkdir -p ~/.nox/bin && cat > ~/.nox/bin/nox-music.sh <<'NOXEOF'\n" + raw +
            "\nNOXEOF\nbash ~/.nox/bin/nox-music.sh install $theme"
        return run(ctx, arrayOf("-c", cmd), true, "nox setup")
    }

    /** recolor the installed player to a nox theme, silently */
    fun syncTheme(ctx: Context, theme: String): String? =
        run(ctx, arrayOf("-c", "[ -f ~/.nox/bin/nox-music.sh ] && bash ~/.nox/bin/nox-music.sh theme $theme"), false, "nox theme")

    /**
     * Open a TUI in a Termux session and return to nox when it exits.
     * If the command FAILS, hold the screen and show the exit code instead of vanishing.
     */
    fun launch(ctx: Context, command: String): String? {
        val script = command + "\n" +
            "rc=\$?\n" +
            "if [ \$rc -ne 0 ]; then echo; echo \"nox: exited with code \$rc\"; echo 'press enter'; read -r _; fi\n" +
            BACK_HOME
        return run(ctx, arrayOf("-c", script), true, command)
    }
}
