package app.nox

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

/** Tiny recursive-descent calculator. `2+2*3`, `(1+2)^3`, `sqrt(2)`, `sin(pi/2)`, `17%5`, `2**10`, `max(3,9)`. */
object Calc {

    class CalcError(msg: String) : Exception(msg)

    fun eval(src: String): Double {
        val p = Parser(src.trim().trimEnd('='))
        val v = p.expr()
        p.end()
        return v
    }

    /** Returns the formatted result, or null when [src] is not a valid expression. */
    fun tryEval(src: String): String? = try {
        if (src.none { it.isDigit() }) null else format(eval(src))
    } catch (_: CalcError) {
        null
    } catch (_: ArithmeticException) {
        null
    }

    fun format(v: Double): String {
        if (v.isNaN()) return "NaN"
        if (v.isInfinite()) return if (v > 0) "∞" else "-∞"
        if (v == floor(v) && abs(v) < 1e15) return v.toLong().toString()
        val bd = BigDecimal(v).round(MathContext(12)).stripTrailingZeros()
        return if (abs(v) in 1e-6..1e15) bd.toPlainString() else bd.toString()
    }

    private class Parser(val s: String) {
        var i = 0

        fun peek(): Char {
            while (i < s.length && s[i].isWhitespace()) i++
            return if (i < s.length) s[i] else '\u0000'
        }

        fun end() {
            if (peek() != '\u0000') throw CalcError("unexpected '${s[i]}'")
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { i++; v += term() }
                    '-' -> { i++; v -= term() }
                    else -> return v
                }
            }
        }

        fun term(): Double {
            var v = unary()
            while (true) {
                when (peek()) {
                    '*', '×' -> {
                        if (i + 1 < s.length && s[i + 1] == '*') return v // ** handled by power()
                        i++; v *= unary()
                    }
                    '/', '÷' -> { i++; v /= unary() }
                    '%' -> { i++; v %= unary() }
                    else -> return v
                }
            }
        }

        fun unary(): Double = when (peek()) {
            '-' -> { i++; -unary() }
            '+' -> { i++; unary() }
            else -> power()
        }

        fun power(): Double {
            val base = atom()
            val c = peek()
            if (c == '^') { i++; return base.pow(unary()) }
            if (c == '*' && i + 1 < s.length && s[i + 1] == '*') { i += 2; return base.pow(unary()) }
            return base
        }

        fun atom(): Double {
            val c = peek()
            if (c == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw CalcError("missing )")
                i++
                return v
            }
            if (c.isDigit() || c == '.') return number()
            if (c.isLetter()) {
                val st = i
                while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '_')) i++
                val name = s.substring(st, i).lowercase()
                if (peek() == '(') {
                    i++
                    val args = ArrayList<Double>()
                    if (peek() != ')') {
                        args.add(expr())
                        while (peek() == ',') { i++; args.add(expr()) }
                    }
                    if (peek() != ')') throw CalcError("missing )")
                    i++
                    return call(name, args)
                }
                return when (name) {
                    "pi" -> PI
                    "e" -> E
                    "tau" -> 2 * PI
                    else -> throw CalcError("unknown name $name")
                }
            }
            throw CalcError(if (c == '\u0000') "unexpected end" else "unexpected '$c'")
        }

        fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            // exponent: only when 'e' is followed by a digit or sign+digit
            if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
                var j = i + 1
                if (j < s.length && (s[j] == '+' || s[j] == '-')) j++
                if (j < s.length && s[j].isDigit()) {
                    while (j < s.length && s[j].isDigit()) j++
                    i = j
                }
            }
            return s.substring(st, i).toDoubleOrNull() ?: throw CalcError("bad number")
        }

        fun call(n: String, a: List<Double>): Double {
            fun one(): Double { if (a.size != 1) throw CalcError("$n takes 1 argument"); return a[0] }
            return when (n) {
                "sqrt" -> sqrt(one())
                "cbrt" -> cbrt(one())
                "abs" -> abs(one())
                "sin" -> sin(one())
                "cos" -> cos(one())
                "tan" -> tan(one())
                "asin" -> asin(one())
                "acos" -> acos(one())
                "atan" -> atan(one())
                "ln" -> ln(one())
                "log" -> log10(one())
                "log2" -> log2(one())
                "exp" -> exp(one())
                "floor" -> floor(one())
                "ceil" -> ceil(one())
                "round" -> Math.round(one()).toDouble()
                "min" -> a.minOrNull() ?: throw CalcError("min needs arguments")
                "max" -> a.maxOrNull() ?: throw CalcError("max needs arguments")
                "pow" -> { if (a.size != 2) throw CalcError("pow takes 2 arguments"); a[0].pow(a[1]) }
                else -> throw CalcError("unknown function $n")
            }
        }
    }
}
