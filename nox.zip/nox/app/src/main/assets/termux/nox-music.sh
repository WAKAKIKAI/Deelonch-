#!/usr/bin/env bash
# nox-music: a clean, themed terminal music player for Termux.  mpd + ncmpcpp + cava, inside tmux.
#
#   bash nox-music.sh wipe              remove everything (this script's AND the old nox setup)
#   bash nox-music.sh install [theme]   install + configure (default theme: gruvbox)
#   bash nox-music.sh theme <theme>     recolor only
#   bash nox-music.sh doctor            diagnose what is wrong
#   bash nox-music.sh repair            rewrite launcher + configs (keeps packages)
#   music stop                          stop mpd, the visualizer and the session
#   themes: void matrix amber ice rose mono nord dracula gruvbox
#
# afterwards just type:  music
set -u
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
HOME="${HOME:-/data/data/com.termux/files/home}"
CFG="$HOME/.config"
FIFO="$PREFIX/tmp/mpd.fifo"
MUSIC="$HOME/storage/music"
TEST="${NOX_TEST:-0}"
NOXBIN="$HOME/.nox/bin"
FONT_URL="https://github.com/JetBrains/JetBrainsMono/raw/master/fonts/ttf/JetBrainsMono-Regular.ttf"

c() { printf '\033[%sm' "$1"; }
say()  { printf '%s>%s %s\n' "$(c 36)" "$(c 0)" "$*"; }
good() { printf '%s✔%s %s\n' "$(c 32)" "$(c 0)" "$*"; }
warn() { printf '%s!%s %s\n' "$(c 33)" "$(c 0)" "$*"; }
bad()  { printf '%s✘%s %s\n' "$(c 31)" "$(c 0)" "$*"; }
die()  { bad "$*"; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

palette() {
  BG='#000000'
  case "$1" in
    void)    FG='#CDD1D6'; DIM='#5B6068'; ACCENT='#8BE9C8'; ACCENT2='#7AA2F7'; OK='#9ECE6A'; WARN='#E0AF68'; ERR='#F7768E' ;;
    matrix)  FG='#B8F5C8'; DIM='#24703C'; ACCENT='#00FF66'; ACCENT2='#39D98A'; OK='#00FF66'; WARN='#D7E04A'; ERR='#FF5F5F' ;;
    amber)   FG='#FFCF66'; DIM='#7A5A12'; ACCENT='#FFB000'; ACCENT2='#FF8C00'; OK='#B8D94A'; WARN='#FFD54A'; ERR='#FF6B4A' ;;
    ice)     FG='#C0CAF5'; DIM='#565F89'; ACCENT='#7DCFFF'; ACCENT2='#BB9AF7'; OK='#9ECE6A'; WARN='#E0AF68'; ERR='#F7768E' ;;
    rose)    FG='#E6D5DB'; DIM='#6E5A63'; ACCENT='#FF8FB1'; ACCENT2='#C6A0F6'; OK='#A6DA95'; WARN='#EED49F'; ERR='#ED8796' ;;
    mono)    FG='#BDBDBD'; DIM='#555555'; ACCENT='#FFFFFF'; ACCENT2='#9E9E9E'; OK='#DDDDDD'; WARN='#BBBBBB'; ERR='#888888' ;;
    nord)    FG='#D8DEE9'; DIM='#4C566A'; ACCENT='#88C0D0'; ACCENT2='#81A1C1'; OK='#A3BE8C'; WARN='#EBCB8B'; ERR='#BF616A' ;;
    dracula) FG='#F8F8F2'; DIM='#6272A4'; ACCENT='#BD93F9'; ACCENT2='#FF79C6'; OK='#50FA7B'; WARN='#F1FA8C'; ERR='#FF5555' ;;
    gruvbox) FG='#EBDBB2'; DIM='#7C6F64'; ACCENT='#FABD2F'; ACCENT2='#FE8019'; OK='#B8BB26'; WARN='#FABD2F'; ERR='#FB4934' ;;
    *) return 1 ;;
  esac
}

# ───────────────────────────── wipe
wipe() {
  say "stopping players"
  have tmux && tmux kill-server 2>/dev/null
  pkill -x mpd 2>/dev/null; pkill -x cava 2>/dev/null; pkill -x ncmpcpp 2>/dev/null
  sleep 1
  say "removing packages (your music files are NOT touched)"
  if [ "$TEST" != 1 ]; then pkg uninstall -y mpd mpc ncmpcpp cava 2>&1 | tail -2; fi
  say "removing configs and the old nox setup"
  rm -rf "$CFG/mpd" "$CFG/ncmpcpp" "$CFG/cava" "$CFG/nox" "$HOME/.ncmpcpp" "$HOME/.mpd" "$HOME/.nox" \
         "$PREFIX/bin/music" "$PREFIX/tmp/mpd.fifo" "$HOME/.termux/colors.properties"
  if [ -f "$HOME/.termux/termux.properties" ]; then
    sed -i '/^fullscreen/d;/^use-fullscreen-workaround/d' "$HOME/.termux/termux.properties"
  fi
  have termux-reload-settings && termux-reload-settings >/dev/null 2>&1
  good "clean. (tmux is kept, it is harmless)"
}

# ───────────────────────────── generated config files
write_theme() {
  mkdir -p "$HOME/.termux" "$CFG/cava" "$CFG/ncmpcpp" "$CFG/nox" "$PREFIX/tmp"

  # ANSI slots remapped onto the palette: every terminal program inherits the theme.
  cat > "$HOME/.termux/colors.properties" <<EOF
background=$BG
foreground=$FG
cursor=$ACCENT
color0=$BG
color1=$ERR
color2=$OK
color3=$WARN
color4=$ACCENT2
color5=$ACCENT2
color6=$ACCENT
color7=$FG
color8=$DIM
color9=$ERR
color10=$OK
color11=$WARN
color12=$ACCENT2
color13=$ACCENT2
color14=$ACCENT
color15=$FG
EOF

  cat > "$CFG/ncmpcpp/config" <<EOF
mpd_host = 127.0.0.1
mpd_port = 6600
mpd_music_dir = $MUSIC
mpd_connection_timeout = 5

user_interface = alternative
startup_screen = playlist
colors_enabled = yes
mouse_support = yes
cyclic_scrolling = yes
centered_cursor = yes
autocenter_mode = yes
titles_visibility = no
header_visibility = yes
statusbar_visibility = yes
display_bitrate = no

main_window_color = white
header_window_color = cyan
volume_color = cyan
state_line_color = 8
state_flags_color = cyan
statusbar_color = white
progressbar_look = ━╸─
progressbar_color = 8
progressbar_elapsed_color = cyan

alternative_header_first_line_format = \$b\$(cyan){%t}|{%f}\$(end)\$/b
alternative_header_second_line_format = {\$(8)%a\$(end){ — \$(8)%b\$(end)}}|{\$(8)%D\$(end)}
song_status_format = {\$b%t\$/b}|{%f}{ \$(8)by\$(end) \$(cyan)%a\$(end)}
playlist_display_mode = columns
browser_display_mode = columns
song_columns_list_format = (52)[white]{t|f} (28)[cyan]{a} (7f)[8]{l}
song_list_format = {\$(cyan)%a\$(end) \$(8)—\$(end) }{%t}|{\$(8)%f\$(end)}\$R{\$(8)%l\$(end)}
now_playing_prefix = \$b\$(cyan)
now_playing_suffix = \$(end)\$/b
current_item_prefix = \$b\$(cyan)
current_item_suffix = \$(end)\$/b
selected_item_prefix = \$(blue)
selected_item_suffix = \$(end)

visualizer_data_source = $FIFO
visualizer_output_name = fifo
visualizer_in_stereo = yes
visualizer_type = spectrum
visualizer_look = ●▮
visualizer_color = cyan, blue
EOF

  cat > "$CFG/cava/config" <<EOF
[general]
framerate = 60
bars = 0
bar_width = 2
bar_spacing = 1
[input]
method = fifo
source = $FIFO
sample_rate = 44100
sample_bits = 16
[output]
method = noncurses
channels = mono
[color]
background = default
foreground = cyan
gradient = 0
[smoothing]
noise_reduction = 77
EOF

  cat > "$CFG/nox/tmux.conf" <<EOF
set -g status off
set -g remain-on-exit failed
set -g mouse on
set -g escape-time 0
set -g default-terminal "screen-256color"
set -g pane-border-style "fg=$DIM"
set -g pane-active-border-style "fg=$ACCENT"
EOF
  have termux-reload-settings && termux-reload-settings >/dev/null 2>&1
  return 0
}

# which audio plugin does THIS mpd build have?
pick_output() {
  if [ "$TEST" = 1 ]; then OUT_TYPE=null; return 0; fi
  local plugins
  plugins="$(mpd --version 2>&1 | sed -n '/Output plugins/,/^$/p')"
  for t in sles osles opensles; do
    if printf '%s' "$plugins" | grep -qw "$t"; then OUT_TYPE=$t; return 0; fi
  done
  bad "this mpd build has no Android audio output. plugins found:"
  printf '%s\n' "$plugins"
  return 1
}

write_mpd() {
  mkdir -p "$CFG/mpd/playlists"
  cat > "$CFG/mpd/mpd.conf" <<EOF
music_directory "$MUSIC"
playlist_directory "$CFG/mpd/playlists"
db_file "$CFG/mpd/database"
state_file "$CFG/mpd/state"
pid_file "$CFG/mpd/pid"
log_file "$CFG/mpd/log"
bind_to_address "127.0.0.1"
port "6600"
auto_update "yes"
restore_paused "yes"
audio_output {
    type "$OUT_TYPE"
    name "Android"
}
audio_output {
    type "fifo"
    name "fifo"
    path "$FIFO"
    format "44100:16:2"
}
EOF
}

write_launcher() {
  mkdir -p "$NOXBIN" "$PREFIX/bin"
  printf '#!%s/bin/bash\n' "$PREFIX" > "$NOXBIN/music"
  cat >> "$NOXBIN/music" <<'EOF'
# music            open the player     music stop   stop everything     music doctor   diagnose
CFG="$HOME/.config"
LOG="$HOME/.nox/music.log"
mkdir -p "$HOME/.nox"
fail() { echo; echo "music: $*"; echo "log: $LOG"; echo "press enter"; read -r _; exit 1; }
[ "${1:-}" = doctor ] && exec bash "$HOME/.nox/bin/nox-music.sh" doctor
if [ "${1:-}" = stop ]; then
  tmux kill-session -t nox-music 2>/dev/null
  mpc stop >/dev/null 2>&1
  pkill -x mpd 2>/dev/null; pkill -x cava 2>/dev/null; pkill -x ncmpcpp 2>/dev/null
  command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock
  echo "music stopped"
  exit 0
fi
export TERM="${TERM:-xterm-256color}"
export LANG="${LANG:-en_US.UTF-8}"
echo "--- $(date) TERM=$TERM LANG=$LANG size=$(stty size 2>&1)" >> "$LOG"
# started from another app the terminal may not have a size yet: wait for it
for _ in $(seq 1 40); do
  case "$(stty size 2>/dev/null)" in ""|"0 0") sleep 0.25 ;; *) break ;; esac
done
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
if ! pgrep -x mpd >/dev/null; then
  mpd "$CFG/mpd/mpd.conf" >> "$LOG" 2>&1
  sleep 1
fi
mpc status >> "$LOG" 2>&1 || fail "mpd is not running. run: music doctor"
mpc update >/dev/null 2>&1
S=nox-music
if ! tmux has-session -t "$S" 2>/dev/null; then
  tmux -u -f "$CFG/nox/tmux.conf" new-session -d -s "$S" -x 100 -y 40 \
    "ncmpcpp --config $CFG/ncmpcpp/config && tmux kill-session -t $S" >> "$LOG" 2>&1 || fail "tmux could not start"
  if command -v cava >/dev/null 2>&1; then
    tmux split-window -v -l 28% -t "$S" "cava -p $CFG/cava/config" >> "$LOG" 2>&1
    tmux select-pane -t "$S:0.0"
  fi
fi
tmux has-session -t "$S" 2>/dev/null || fail "the player closed immediately"
[ "${NOX_NOATTACH:-0}" = 1 ] && exit 0
tmux -u attach -t "$S" || fail "tmux attach failed"
EOF
  chmod +x "$NOXBIN/music"
  cp "$0" "$NOXBIN/nox-music.sh" 2>/dev/null
  ln -sf "$NOXBIN/music" "$PREFIX/bin/music"
}

# ───────────────────────────── install
install() {
  local theme="${1:-gruvbox}"
  palette "$theme" || die "unknown theme '$theme' (void matrix amber ice rose mono nord dracula gruvbox)"
  say "theme: $theme"
  mkdir -p "$CFG/nox"; echo "$theme" > "$CFG/nox/theme"

  if [ "$TEST" != 1 ]; then
    say "installing packages (a minute or two)"
    pkg update -y >/dev/null 2>&1 || warn "pkg update had problems, continuing"
    pkg install -y mpd mpc ncmpcpp tmux curl || die "pkg install failed. try: termux-change-repo, then run this again"
    pkg install -y cava >/dev/null 2>&1 && good "cava installed" || warn "cava is not available, you will get the player without the visualizer"
  fi
  for t in mpd mpc ncmpcpp tmux; do have "$t" || die "$t did not install"; done
  good "mpd, mpc, ncmpcpp, tmux present"

  if [ ! -d "$MUSIC" ]; then
    say "asking Android for storage access. tap ALLOW."
    have termux-setup-storage && termux-setup-storage
    for _ in $(seq 1 30); do [ -d "$MUSIC" ] && break; sleep 1; done
  fi
  [ -d "$MUSIC" ] || die "no $MUSIC. allow storage for Termux (Android settings > Apps > Termux > Permissions), run termux-setup-storage, then run this again"
  good "music folder: $MUSIC ($(find -L "$MUSIC" -type f 2>/dev/null | wc -l) files)"

  pick_output || die "cannot continue without an audio output"
  good "audio output: $OUT_TYPE"
  write_mpd; write_theme; write_launcher
  good "configs written"

  if [ "$TEST" != 1 ] && [ ! -s "$HOME/.termux/font.ttf" ]; then
    say "downloading JetBrains Mono (same font as nox)"
    if curl -fsSL -m 90 -o "$HOME/.termux/font.ttf" "$FONT_URL" && [ "$(wc -c < "$HOME/.termux/font.ttf")" -gt 100000 ]; then
      good "font installed"
    else
      rm -f "$HOME/.termux/font.ttf"; warn "font download failed, skipping (cosmetic)"
    fi
  fi
  if [ "$TEST" != 1 ]; then
    P="$HOME/.termux/termux.properties"; mkdir -p "$HOME/.termux"; touch "$P"
    grep -q '^fullscreen' "$P" || echo 'fullscreen = true' >> "$P"
    grep -q '^use-fullscreen-workaround' "$P" || echo 'use-fullscreen-workaround = true' >> "$P"
  fi
  have termux-reload-settings && termux-reload-settings >/dev/null 2>&1

  say "starting mpd and scanning your music"
  pkill -x mpd 2>/dev/null; sleep 1
  mpd "$CFG/mpd/mpd.conf"; sleep 2
  mpc update --wait >/dev/null 2>&1
  doctor
  echo
  good "done. type:  music"
}

# ───────────────────────────── repair: rewrite launcher + configs, keep packages
repair() {
  local theme
  theme="$(cat "$CFG/nox/theme" 2>/dev/null || echo gruvbox)"
  palette "$theme" || { theme=gruvbox; palette gruvbox; }
  have tmux && tmux kill-server 2>/dev/null
  pick_output || die "cannot continue without an audio output"
  write_mpd; write_theme; write_launcher
  good "launcher and configs rewritten (theme: $theme). now try: music"
}

# ───────────────────────────── doctor
doctor() {
  echo
  for t in mpd mpc ncmpcpp tmux cava; do have "$t" && good "$t installed" || { [ "$t" = cava ] && warn "cava missing (optional)" || bad "$t missing"; }; done
  [ -d "$MUSIC" ] && good "music folder exists" || bad "music folder missing: $MUSIC  (run termux-setup-storage)"
  [ -x "$NOXBIN/music" ] && good "launcher ok: $(head -1 "$NOXBIN/music")" || bad "launcher missing or not executable (run: repair)"
  [ -f "$CFG/mpd/mpd.conf" ] && good "mpd.conf exists" || bad "mpd.conf missing (run: install)"
  if pgrep -x mpd >/dev/null; then good "mpd is running"; else bad "mpd is NOT running. start it and read the error:  mpd --no-daemon --stdout $CFG/mpd/mpd.conf"; fi
  if mpc status >/dev/null 2>&1; then
    good "mpc can talk to mpd"
    songs="$(mpc stats 2>/dev/null | awk '/Songs/ {print $2}')"
    [ "${songs:-0}" -gt 0 ] 2>/dev/null && good "$songs songs in the library" || warn "library is empty: put music in /sdcard/Music, then run: mpc update"
  else
    bad "mpc cannot reach mpd"
  fi
}

case "${1:-help}" in
  wipe)    wipe ;;
  install) install "${2:-gruvbox}" ;;
  theme)   palette "${2:-}" || die "usage: theme <void|matrix|amber|ice|rose|mono|nord|dracula|gruvbox>"; write_theme; mkdir -p "$CFG/nox"; echo "$2" > "$CFG/nox/theme"; good "theme: $2" ;;
  doctor)  doctor ;;
  repair)  repair ;;
  *) sed -n '2,11p' "$0" ;;
esac
