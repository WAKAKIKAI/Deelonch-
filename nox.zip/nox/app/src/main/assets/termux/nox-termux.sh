#!/data/data/com.termux/files/usr/bin/bash
# nox <-> Termux bridge. nox substitutes the @COLOURS@ from your current theme, then runs:
#   bash -c "<this file>" nox <setup|theme>
MODE="${1:-theme}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
HOME="${HOME:-/data/data/com.termux/files/home}"
CFG="$HOME/.config"
FIFO="$PREFIX/tmp/mpd.fifo"
BG='@BG@'; FG='@FG@'; DIM='@DIM@'; ACCENT='@ACCENT@'; ACCENT2='@ACCENT2@'
OK='@OK@'; WARN='@WARN@'; ERR='@ERR@'

write_theme() {
  mkdir -p "$HOME/.termux" "$CFG/cava" "$CFG/ncmpcpp" "$CFG/nox"

  # terminal colours: ANSI slots mapped onto the nox palette, so every TUI inherits the theme
  cat > "$HOME/.termux/colors.properties" <<EOF
background=$BG
foreground=$FG
cursor=$ACCENT
color0=$BG
color1=$ERR
color2=$OK
color3=$WARN
color4=$ACCENT2
color5=$ACCENT2
color6=$ACCENT
color7=$FG
color8=$DIM
color9=$ERR
color10=$OK
color11=$WARN
color12=$ACCENT2
color13=$ACCENT2
color14=$ACCENT
color15=$FG
EOF

  cat > "$CFG/cava/config" <<EOF
[general]
framerate = 60
bars = 0
bar_width = 2
bar_spacing = 1
[input]
method = fifo
source = $FIFO
sample_rate = 44100
sample_bits = 16
[output]
method = noncurses
channels = mono
[color]
gradient = 1
gradient_count = 2
gradient_color_1 = '$ACCENT2'
gradient_color_2 = '$ACCENT'
[smoothing]
noise_reduction = 77
EOF

  # ncmpcpp uses ANSI names, which the colours above already remap
  cat > "$CFG/ncmpcpp/config" <<EOF
mpd_host = 127.0.0.1
mpd_port = 6600
mpd_music_dir = $HOME/storage/music
visualizer_data_source = $FIFO
visualizer_output_name = fifo
visualizer_in_stereo = yes
visualizer_type = spectrum
visualizer_look = +|
colors_enabled = yes
main_window_color = white
header_window_color = cyan
volume_color = cyan
state_line_color = cyan
state_flags_color = cyan
statusbar_color = white
progressbar_color = 8
progressbar_elapsed_color = cyan
current_item_prefix = \$(cyan)\$r
current_item_suffix = \$/r\$(end)
user_interface = classic
cyclic_scrolling = yes
EOF

  cat > "$CFG/nox/tmux.conf" <<EOF
set -g status off
set -g mouse on
set -g escape-time 0
set -g default-terminal "screen-256color"
set -g pane-border-style "fg=$DIM"
set -g pane-active-border-style "fg=$ACCENT"
EOF

  termux-reload-settings >/dev/null 2>&1 || true
}

setup() {
  echo "nox: installing the music stack (mpd, ncmpcpp, tmux, cava)..."
  pkg update -y && pkg install -y mpd mpc ncmpcpp tmux || { echo "pkg install failed"; read -r _; return 1; }
  pkg install -y cava || echo "(cava is not available here, the tmux layout will just show ncmpcpp)"

  if [ ! -d "$HOME/storage/music" ]; then
    echo "nox: allow storage access in the dialog that pops up..."
    termux-setup-storage
    sleep 8
  fi

  mkdir -p "$CFG/mpd/playlists" "$HOME/.nox/bin" "$PREFIX/tmp"

  cat > "$CFG/mpd/mpd.conf" <<EOF
music_directory "$HOME/storage/music"
playlist_directory "$CFG/mpd/playlists"
db_file "$CFG/mpd/database"
state_file "$CFG/mpd/state"
pid_file "$CFG/mpd/pid"
log_file "$CFG/mpd/log"
bind_to_address "127.0.0.1"
port "6600"
audio_output {
    type "sles"
    name "Android"
}
audio_output {
    type "fifo"
    name "fifo"
    path "$FIFO"
    format "44100:16:2"
}
EOF

  cat > "$HOME/.nox/bin/music" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# opened by nox: `music`
termux-wake-lock 2>/dev/null
pgrep -x mpd >/dev/null || mpd
sleep 1
mpc update >/dev/null 2>&1
mpc status >/dev/null 2>&1 || { echo "mpd did not start. try: mpd --no-daemon --stdout"; read -r _; exit 1; }
S=nox-music
if ! tmux has-session -t "$S" 2>/dev/null; then
  tmux -f "$HOME/.config/nox/tmux.conf" new-session -d -s "$S" ncmpcpp
  if command -v cava >/dev/null 2>&1; then
    tmux split-window -v -l 30% -t "$S" "cava -p $HOME/.config/cava/config"
    tmux select-pane -t "$S:0.0"
  fi
fi
tmux attach -t "$S"
EOF
  chmod +x "$HOME/.nox/bin/music"

  PROPS="$HOME/.termux/termux.properties"
  mkdir -p "$HOME/.termux"; touch "$PROPS"
  grep -q '^fullscreen' "$PROPS" || echo 'fullscreen = true' >> "$PROPS"
  grep -q '^use-fullscreen-workaround' "$PROPS" || echo 'use-fullscreen-workaround = true' >> "$PROPS"

  write_theme
  echo
  echo "nox: done. put music in /sdcard/Music, then type  music  in nox."
  sleep 4
  am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1
}

case "$MODE" in
  setup) setup ;;
  *) write_theme ;;
esac
